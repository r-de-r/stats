# Julia で統計解析　第 7 章　検定と推定


```julia
Version()
```

    最新バージョン 2024-07-18 07:55


この章に示す統計検定を行う関数の詳細は以下を参照のこと。<br>
[外部リンク：HypothesisTests package](https://juliastats.org/HypothesisTests.jl/stable/)

この章に示す統計検定を行う前に，以下を行っておく。


```julia
using HypothesisTests
```

## 検定関数関数の呼び出し方

検定関数は以下のように定義されている（引数の型宣言を省略）。

`NameOfTest(a, b, c, d=2, e="abc"; f=100, g=20.0)`

`;` の左にある「名前=値」の形式をした引数はオプション引数と呼ばれ，省略可能である。省略された場合は指定された値がデフォルトとして使われる。`;` がなければ，「名前=値」の形式をした引数はすべてオプション引数である。

たとえば，上の例のようにオプション引き数が 2 個ある場合は 3 通りの呼び出し方がある。

- 2 個の引数すべてを指定する。<br>
`NameOfTest(a, b, c, 3, "xyz")`<br>
`d=3`, `e="xyz"` として呼び出される

- 1 個の引数だけを指定する。<br>
`NameOfTest(a, b, c, 4)`<br>
`d=4` で，省略された `e` はデフォルトの `"abc"` として呼び出される

- 全く指定しない。<br>
`NameOfTest(a, b, c)`<br>
省略された `d`, `e` はデフォルトの `2`, `"abc"` として呼び出される

もし，引数の記述において，`;` があれば，その後にあるすべての「名前=値」の形式をした引数はキーワード引数と呼ばれ，省略可能である。省略された場合は指定された値がデフォルトとして使われる。デフォルト以外の値を指定する必要がある場合は「名前=値」の形式で指定しなければならない。

たとえば，上の例のようにキーワード引き数が `f`, `g` のような名前を持つなら，`f=123`, `g=25.6` のように指定する。

なお，キーワード変数を指定して呼び出す場合には，通常は区切り文字 `;` は `,` にしてもかまわない。

## 検定関数関数により得られる結果の利用法

例えば，検定関数が

`NameOfTest(a, b, c, d=2, e="abc"; f=100, g=20.0)`

のように呼ばれると，REPL では検定結果をまとめて，見やすい形式で表示してくれる。
REPL でない場合は

`result = NameOfTest(a, b, c, d=2, e="abc"; f=100, g=20.0)`

のように，関数の戻り値を変数に代入しておき，`println(result)` とすれば同じように表示される。

また，戻り値はいくつかあり，個々の検定結果の数値を選択して表示することもできる。たとえば，戻り値の要素が `a`，`b` の場合には `println(result.a)`，`println(result.b)` のようにすればよい。

なお，HypothesisTests に含まれる関数はデフォルトで両側検定の場合の $p$ 値と，信頼率が95% の場合の信頼区間の表示するが，片側検定や信頼率が 95% 以外の信頼区間を表示する場合には，`pvalue` メソッド（関数）と `confint` メソッド（関数）を呼ばなければならない。

関数の戻り値を `result` に代入しているとして，

- `pvalue()` の使用法

`pvalue(result)`              # デフォルトで両側検定<br>
`pvalue(result, tail=:both)`  # 両側検定<br>
`pvalue(result, tail=:left)`  # 片側検定<br>
`pvalue(result, tail=:right)` # 片側検定<br>

- `confint()` の使用法

`confint(result, tail=:both)` # デフォルトで両側に棄却域を持つ 95％ 信頼区間<br>
`confint(result, level=0.99)` # デフォルトで両側に棄却域を持つ 99％ 信頼区間<br>
`confint(result, tail=:both, level=0.99)`  # 両側に棄却域を持つ 99％ 信頼区間<br>
`confint(result, tail=:left, level=0.99)`  # 右側に棄却域を持つ 99% 信頼区間<br>
`confint(result, tail=:right, level=0.99)` # 左側に棄却域を持つ 99% 信頼区間

検定と推定は表裏一体である。HypothesisTest に含まれる検定関数は $p$ 値だけではなく信頼区間を求めるものもある。

$p$ 値が有意水準 `(1 - level)` より小さいことと，信頼区間に検定統計量が含まれないことは同じこと「帰無仮説が棄却される」である。


## 分布の検定

引数に観察値の度数分布ベクトルが与えられた場合，観察値が特定の確率に従っているかどうかを検定する。

ここでは，ピアソンの $\chi^2$ 検定と，対数尤度比検定（$G^2$ 検定）を提示する。

一般的に，$G^2$ 検定のほうが検定力は高い（$p$ 値が小さい）。

### 観察度数が一様かどうかの検定

たとえば，16 回サイコロを振ったところ，1~6 のそれぞれの目が，4, 2, 1, 3, 4, 2 回ずつ出たとする。「本来サイコロはどの目が出る確率も同じはずなので，観察された目の出方はおかしいのではないか」という疑問に答えるための検定である。

#### ピアソンの $\chi^2$ 検定

関数定義<br>
`PowerDivergenceTest(x; lambda = 1.0)`

第 1 引数に観察度数ベクトル，第 2 引数に `lambda=1.0` を指定する。注意すべき点は `lambda=1` ではないということである（`MethodError` が出るので気づく）。

■ 使用例


```julia
result = PowerDivergenceTest([4, 2, 1, 3, 4, 2], lambda=1.0) # ピアソンの$\chi^2$検定
```




    Pearson's Chi-square Test
    -------------------------
    Population details:
        parameter of interest:   Multinomial Probabilities
        value under h_0:         [0.166667, 0.166667, 0.166667, 0.166667, 0.166667, 0.166667]
        point estimate:          [0.25, 0.125, 0.0625, 0.1875, 0.25, 0.125]
        95% confidence interval: [(0.0625, 0.5238), (0.0, 0.3988), (0.0, 0.3363), (0.0, 0.4613), (0.0625, 0.5238), (0.0, 0.3988)]
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        one-sided p-value:           0.7385
    
    Details:
        Sample size:        16
        statistic:          2.75
        degrees of freedom: 5
        residuals:          [0.816497, -0.408248, -1.02062, 0.204124, 0.816497, -0.408248]
        std. residuals:     [0.894427, -0.447214, -1.11803, 0.223607, 0.894427, -0.447214]




■ 個別に表示できる統計量

- 概要


```julia
result = PowerDivergenceTest([4, 2, 1, 3, 4, 2], lambda=1.0);
p = pvalue(result)
println("Chisq. = $(result.stat),  df = $(result.df),  p value = $p")
```

    Chisq. = 2.75,  df = 5,  p value = 0.7384611787603711


以下のような関数を定義しておくと，`chisq_test(観察ベクトル)` とするだけで結果が表示できる。


```julia
function chisq_test(x; lambda=1.0, theta0=ones(length(x))/length(x))
    result = PowerDivergenceTest(x; lambda, theta0)
    p = pvalue(result)
    println("χ-sq. = $(result.stat),  df = $(result.df),  p value = $p")
end;
```


```julia
chisq_test([4, 2, 1, 3, 4, 2])
```

    χ-sq. = 2.75,  df = 5,  p value = 0.7384611787603711



```julia
chisq_test([21, 12, 5, 4]) 
```

    χ-sq. = 17.61904761904762,  df = 3,  p value = 0.0005270259708713794


- $p$ 値　この検定では `tail=:both`，`tail=:left` は使用してはいけない<br>
上に示した結果の一覧表示で `"one-sided p-value: 0.7385"` とあるのは，この検定が `"one-sided"` はないので誤った記述である。棄却域は $\chi^2$ 分布の右側にしかないが，本来この検定は意味的に両側検定である（両側検定，片側検定という区分分け自体が不要である）。


```julia
pvalue(result)
```




    0.7384611787603711




```julia
pvalue(result, tail=:right)
```




    0.7384611787603711



- 信頼区間　信頼区間は度数分布の確率の信頼区間である。<br>
この検定では，`tail=:left`，`tail=:right` は使用してはいけない（`pvalue()` の場合と違うので注意が必要である）。


```julia
confint(result)
```




    6-element Vector{Tuple{Float64, Float64}}:
     (0.0625, 0.5237538769784804)
     (0.0, 0.3987538769784804)
     (0.0, 0.3362538769784804)
     (0.0, 0.4612538769784804)
     (0.0625, 0.5237538769784804)
     (0.0, 0.3987538769784804)




```julia
confint(result, tail=:both)
```




    6-element Vector{Tuple{Float64, Float64}}:
     (0.0625, 0.5237538769784804)
     (0.0, 0.3987538769784804)
     (0.0, 0.3362538769784804)
     (0.0, 0.4612538769784804)
     (0.0625, 0.5237538769784804)
     (0.0, 0.3987538769784804)



- lambda　$\lambda$


```julia
result.lambda
```




    1.0



- `n`　サンプルサイズ


```julia
result.n
```




    16



- `observed`　観察度数分布


```julia
result.observed
```




    6×1 Matrix{Int64}:
     4
     2
     1
     3
     4
     2



- `thetahat`　観察度数の確率<br>
`result.observed / result.n`


```julia
result.thetahat
```




    6-element Vector{Float64}:
     0.25
     0.125
     0.0625
     0.1875
     0.25
     0.125



- `theta0`　帰無仮説の下での観察度数の確率（等確率）<br>
`ones(length(result.observed)) / length(result.observed)`


```julia
round.(result.theta0, digits=5)
```




    6-element Vector{Float64}:
     0.16667
     0.16667
     0.16667
     0.16667
     0.16667
     0.16667



- `expected`　帰無仮説の下での観察度数の期待値（同じ値）<br>
`result.n * result.theta0`


```julia
round.(result.expected, digits=5)
```




    6×1 Matrix{Float64}:
     2.66667
     2.66667
     2.66667
     2.66667
     2.66667
     2.66667



- `stat`　検定統計量（$\chi^2$ 分布にしたがう）<br>
`sum((result.observed - result.expected).^2 ./ result.expected)`


```julia
result.stat
```




    2.75



- `df`　$\chi^2$ 分布の自由度<br>
`length(result.observed) - 1`


```julia
result.df
```




    5



- `residuals`　残差<br>
`(result.observed - result.expected) ./ sqrt.(result.expected)`


```julia
round.(result.residuals, digits=5)
```




    6×1 Matrix{Float64}:
      0.8165
     -0.40825
     -1.02062
      0.20412
      0.8165
     -0.40825



- `stdresiduals`　標準化残差<br>
`V = result.n .* result.theta0 .* (1 .- result.theta0)`<br>
`(result.observed - result.expected) ./ sqrt.(V)`


```julia
round.(result.stdresiduals, digits=5)
```




    6×1 Matrix{Float64}:
      0.89443
     -0.44721
     -1.11803
      0.22361
      0.89443
     -0.44721



#### 対数尤度比検定（$G^2$ 検定）

関数定義<br>
`PowerDivergenceTest(x; lambda = 0.0)`

対数尤度比に基づく検定は，「3.1.1.　ピアソンの $\chi^2$ 検定」と同じ `PowerDivergenceTest()` で `lambda=0.0` を指定することで行うことができる。

■ 使用例


```julia
result = PowerDivergenceTest([4, 2, 1, 3, 4, 2], lambda=0.0)
```




    Multinomial Likelihood Ratio Test
    ---------------------------------
    Population details:
        parameter of interest:   Multinomial Probabilities
        value under h_0:         [0.166667, 0.166667, 0.166667, 0.166667, 0.166667, 0.166667]
        point estimate:          [0.25, 0.125, 0.0625, 0.1875, 0.25, 0.125]
        95% confidence interval: [(0.0625, 0.5238), (0.0, 0.3988), (0.0, 0.3363), (0.0, 0.4613), (0.0625, 0.5238), (0.0, 0.3988)]
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        one-sided p-value:           0.7106
    
    Details:
        Sample size:        16
        statistic:          2.931024858031232
        degrees of freedom: 5
        residuals:          [0.816497, -0.408248, -1.02062, 0.204124, 0.816497, -0.408248]
        std. residuals:     [0.894427, -0.447214, -1.11803, 0.223607, 0.894427, -0.447214]




■ 個別に表示できる統計量

- 概要

前項の `chisq_test()` と同様に以下の関数を定義して簡潔な結果を表示する。


```julia
function G2_test(x; theta0=ones(length(x))/length(x), lambda=0.0)
    result = PowerDivergenceTest(x; theta0, lambda);
    p = pvalue(result)
    println("G-sq. = $(result.stat),  df = $(result.df),  p value = $p")
end

G2_test([4, 2, 1, 3, 4, 2])
```

    G-sq. = 2.931024858031232,  df = 5,  p value = 0.710619024390339



```julia
G2_test([21, 12, 5, 4]) 
```

    G-sq. = 17.176914390863786,  df = 3,  p value = 0.0006499306837478541


- $p$ 値　この検定では `tail=:both`，`tail=:left` は使用してはいけない<br>
上に示した結果の一覧表示で `"one-sided p-value: 0.7106"` とあるのは，この検定が `"one-sided"` はないので誤った記述である。棄却域は $\chi^2$ 分布の右側にしかないが，本来この検定は意味的に両側検定である（両側検定，片側検定という区分分け自体が不要である）。


```julia
pvalue(result)
```




    0.710619024390339




```julia
pvalue(result, tail=:right)
```




    0.710619024390339



- 信頼区間　信頼区間は度数分布の確率の信頼区間である。<br>
この検定では，`tail=:left`，`tail=:right` は使用してはいけない（`pvalue()` の場合と違うので注意が必要である）。


```julia
confint(result)
```




    6-element Vector{Tuple{Float64, Float64}}:
     (0.0625, 0.5237538769784804)
     (0.0, 0.3987538769784804)
     (0.0, 0.3362538769784804)
     (0.0, 0.4612538769784804)
     (0.0625, 0.5237538769784804)
     (0.0, 0.3987538769784804)




```julia
confint(result, tail=:both)
```




    6-element Vector{Tuple{Float64, Float64}}:
     (0.0625, 0.5237538769784804)
     (0.0, 0.3987538769784804)
     (0.0, 0.3362538769784804)
     (0.0, 0.4612538769784804)
     (0.0625, 0.5237538769784804)
     (0.0, 0.3987538769784804)



- lambda　$\lambda$


```julia
result.lambda
```




    0.0



- `n`　サンプルサイズ


```julia
result.n
```




    16



- `observed`　観察度数分布


```julia
result.observed
```




    6×1 Matrix{Int64}:
     4
     2
     1
     3
     4
     2



- `thetahat`　観察度数の確率<br>
`result.observed / result.n`


```julia
result.thetahat
```




    6-element Vector{Float64}:
     0.25
     0.125
     0.0625
     0.1875
     0.25
     0.125



- `theta0`　帰無仮説の下での観察度数の確率（等確率）<br>
`ones(length(result.observed)) / length(result.observed)`


```julia
round.(result.theta0, digits=5)
```




    6-element Vector{Float64}:
     0.16667
     0.16667
     0.16667
     0.16667
     0.16667
     0.16667



- `expected`　帰無仮説の下での観察度数の期待値（同じ値）<br>
`result.n * result.theta0`


```julia
round.(result.expected, digits=5)
```




    6×1 Matrix{Float64}:
     2.66667
     2.66667
     2.66667
     2.66667
     2.66667
     2.66667



- `stat`　検定統計量（$\chi^2$ 分布にしたがう）<br>
`sum((result.observed - result.expected).^2 ./ result.expected)`


```julia
result.stat
```




    2.931024858031232



- `df`　$\chi^2$ 分布の自由度<br>
`length(result.observed) - 1`


```julia
result.df
```




    5



- `residuals`　残差<br>
`(result.observed - result.expected) ./ sqrt.(result.expected)`


```julia
round.(result.residuals, digits=5)
```




    6×1 Matrix{Float64}:
      0.8165
     -0.40825
     -1.02062
      0.20412
      0.8165
     -0.40825



- `stdresiduals`　標準化残差<br>
`V = result.n .* result.theta0 .* (1 .- result.theta0)`<br>
`(result.observed - result.expected) ./ sqrt.(V)`


```julia
round.(result.stdresiduals, digits=5)
```




    6×1 Matrix{Float64}:
      0.89443
     -0.44721
     -1.11803
      0.22361
      0.89443
     -0.44721



### 観察度数が理論比に從うかどうかの検定

観察値が理論比に從うかどうかの検定は `PowerDivergenceTest()` で，観察値の度数分布ベクトルと，理論比のベクトル `theta0` を与える。

理論比は，合計して 1 にならなければならないが，分数で与えることもできる。

#### ピアソンの $\chi^2$ 検定

関数定義<br>
`PowerDivergenceTest(x; theta0 = ones(length(x))/length(x), lambda = 1.0)`

`PowerDivergenceTest()` で，`lambda=1.0` を指定する。

■ 使用例


```julia
result = PowerDivergenceTest([21, 12, 5, 4], theta0=[9/16, 3/16, 3/16, 1/16], lambda=1.0)
```




    Pearson's Chi-square Test
    -------------------------
    Population details:
        parameter of interest:   Multinomial Probabilities
        value under h_0:         [0.5625, 0.1875, 0.1875, 0.0625]
        point estimate:          [0.5, 0.285714, 0.119048, 0.0952381]
        95% confidence interval: [(0.3571, 0.6576), (0.1429, 0.4433), (0.0, 0.2766), (0.0, 0.2528)]
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        one-sided p-value:           0.2384
    
    Details:
        Sample size:        42
        statistic:          4.22222222222222
        degrees of freedom: 3
        residuals:          [-0.540062, 1.46994, -1.0245, 0.848668]
        std. residuals:     [-0.816497, 1.63075, -1.13658, 0.876501]




■ 個別に表示できる統計量

- 概要

前節で定義した chisq_test() を使うと以下のようになる。


```julia
chisq_test([21, 12, 5, 4], theta0=[9/16, 3/16, 3/16, 1/16]) # ピアソンのχ二乗検定
```

    χ-sq. = 4.22222222222222,  df = 3,  p value = 0.23844641563476865


- $p$ 値　この検定では `tail=:both`，`tail=:left` は使用してはいけない<br>
上に示した結果の一覧表示で `"one-sided p-value: 0.2384"` とあるのは，この検定が `"one-sided"` はないので誤った記述である。棄却域は $\chi^2$ 分布の右側にしかないが，本来この検定は意味的に両側検定である（両側検定，片側検定という区分分け自体が不要である）。


```julia
pvalue(result)
```




    0.23844641563476865




```julia
pvalue(result, tail=:right)
```




    0.23844641563476865



- 信頼区間　信頼区間は度数分布の確率の信頼区間である。<br>
この検定では，`tail=:left`，`tail=:right` は使用してはいけない（`pvalue()` の場合と違うので注意が必要である）。


```julia
confint(result)
```




    4-element Vector{Tuple{Float64, Float64}}:
     (0.35714285714285715, 0.6575992779891421)
     (0.14285714285714285, 0.4433135637034278)
     (0.0, 0.2766468970367611)
     (0.0, 0.2528373732272373)




```julia
confint(result, tail=:both)
```




    4-element Vector{Tuple{Float64, Float64}}:
     (0.35714285714285715, 0.6575992779891421)
     (0.14285714285714285, 0.4433135637034278)
     (0.0, 0.2766468970367611)
     (0.0, 0.2528373732272373)



- lambda　$\lambda$


```julia
result.lambda
```




    1.0



- `n`　サンプルサイズ


```julia
result.n
```




    42



- `observed`　観察度数分布


```julia
result.observed
```




    4×1 Matrix{Int64}:
     21
     12
      5
      4



- `thetahat`　観察度数の確率<br>
`result.observed / result.n`


```julia
result.thetahat
```




    4-element Vector{Float64}:
     0.5
     0.2857142857142857
     0.11904761904761904
     0.09523809523809523



- `theta0`　帰無仮説の下での観察度数の確率（等確率）<br>
`ones(length(result.observed)) / length(result.observed)`


```julia
round.(result.theta0, digits=5)
```




    4-element Vector{Float64}:
     0.5625
     0.1875
     0.1875
     0.0625



- `expected`　帰無仮説の下での観察度数の期待値（同じ値）<br>
`result.n * result.theta0`


```julia
round.(result.expected, digits=5)
```




    4×1 Matrix{Float64}:
     23.625
      7.875
      7.875
      2.625



- `stat`　検定統計量（$\chi^2$ 分布にしたがう）<br>
`sum((result.observed - result.expected).^2 ./ result.expected)`


```julia
result.stat
```




    4.22222222222222



- `df`　$\chi^2$ 分布の自由度<br>
`length(result.observed) - 1`


```julia
result.df
```




    3



- `residuals`　残差<br>
`(result.observed - result.expected) ./ sqrt.(result.expected)`


```julia
round.(result.residuals, digits=5)
```




    4×1 Matrix{Float64}:
     -0.54006
      1.46994
     -1.0245
      0.84867



- `stdresiduals`　標準化残差<br>
`V = result.n .* result.theta0 .* (1 .- result.theta0)`<br>
`(result.observed - result.expected) ./ sqrt.(V)`


```julia
round.(result.stdresiduals, digits=5)
```




    4×1 Matrix{Float64}:
     -0.8165
      1.63075
     -1.13658
      0.8765



#### 対数尤度比検定（$G^2$ 検定）

関数定義<br>
`PowerDivergenceTest(x; theta0 = ones(length(x))/length(x), lambda = 0.0)`

`PowerDivergenceTest()` で，`lambda=1.0` を指定する。

■ 使用例


```julia
result = PowerDivergenceTest([21, 12, 5, 4], theta0=[9/16, 3/16, 3/16, 1/16], lambda=0.0)
```




    Multinomial Likelihood Ratio Test
    ---------------------------------
    Population details:
        parameter of interest:   Multinomial Probabilities
        value under h_0:         [0.5625, 0.1875, 0.1875, 0.0625]
        point estimate:          [0.5, 0.285714, 0.119048, 0.0952381]
        95% confidence interval: [(0.3571, 0.6576), (0.1429, 0.4433), (0.0, 0.2766), (0.0, 0.2528)]
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        one-sided p-value:           0.2626
    
    Details:
        Sample size:        42
        statistic:          3.9893906620976454
        degrees of freedom: 3
        residuals:          [-0.540062, 1.46994, -1.0245, 0.848668]
        std. residuals:     [-0.816497, 1.63075, -1.13658, 0.876501]




■ 個別に表示できる統計量

- 概要

前節で定義した `G2_test()` を使うと以下のようになる。


```julia
G2_test([21, 12, 5, 4], theta0=[9/16, 3/16, 3/16, 1/16]) # 対数尤度比検定（G2検定）
```

    G-sq. = 3.9893906620976454,  df = 3,  p value = 0.26261202803389555


- $p$ 値　この検定では `tail=:both`，`tail=:left` は使用してはいけない<br>
上に示した結果の一覧表示で `"one-sided p-value: 0.2626"` とあるのは，この検定が `"one-sided"` はないので誤った記述である。棄却域は $\chi^2$ 分布の右側にしかないが，本来この検定は意味的に両側検定である（両側検定，片側検定という区分分け自体が不要である）。


```julia
pvalue(result)
```




    0.26261202803389555




```julia
pvalue(result, tail=:right)
```




    0.26261202803389555



- 信頼区間　信頼区間は度数分布の確率の信頼区間である。<br>
この検定では，`tail=:left`，`tail=:right` は使用してはいけない（`pvalue()` の場合と違うので注意が必要である）。


```julia
confint(result)
```




    4-element Vector{Tuple{Float64, Float64}}:
     (0.35714285714285715, 0.6575992779891421)
     (0.14285714285714285, 0.4433135637034278)
     (0.0, 0.2766468970367611)
     (0.0, 0.2528373732272373)




```julia
confint(result, tail=:both)
```




    4-element Vector{Tuple{Float64, Float64}}:
     (0.35714285714285715, 0.6575992779891421)
     (0.14285714285714285, 0.4433135637034278)
     (0.0, 0.2766468970367611)
     (0.0, 0.2528373732272373)



- lambda　$\lambda$


```julia
result.lambda
```




    0.0



- `n`　サンプルサイズ


```julia
result.n
```




    42



- `observed`　観察度数分布


```julia
result.observed
```




    4×1 Matrix{Int64}:
     21
     12
      5
      4



- `thetahat`　観察度数の確率<br>
`result.observed / result.n`


```julia
result.thetahat
```




    4-element Vector{Float64}:
     0.5
     0.2857142857142857
     0.11904761904761904
     0.09523809523809523



- `theta0`　帰無仮説の下での観察度数の確率（等確率）<br>
`ones(length(result.observed)) / length(result.observed)`


```julia
round.(result.theta0, digits=5)
```




    4-element Vector{Float64}:
     0.5625
     0.1875
     0.1875
     0.0625



- `expected`　帰無仮説の下での観察度数の期待値（同じ値）<br>
`result.n * result.theta0`


```julia
round.(result.expected, digits=5)
```




    4×1 Matrix{Float64}:
     23.625
      7.875
      7.875
      2.625



- `stat`　検定統計量（$\chi^2$ 分布にしたがう）<br>
`sum((result.observed - result.expected).^2 ./ result.expected)`


```julia
result.stat
```




    3.9893906620976454



- `df`　$\chi^2$ 分布の自由度<br>
`length(result.observed) - 1`


```julia
result.df
```




    3



- `residuals`　残差<br>
`(result.observed - result.expected) ./ sqrt.(result.expected)`


```julia
round.(result.residuals, digits=5)
```




    4×1 Matrix{Float64}:
     -0.54006
      1.46994
     -1.0245
      0.84867



- `stdresiduals`　標準化残差<br>
`V = result.n .* result.theta0 .* (1 .- result.theta0)`<br>
`(result.observed - result.expected) ./ sqrt.(V)`


```julia
round.(result.stdresiduals, digits=5)
```




    4×1 Matrix{Float64}:
     -0.8165
      1.63075
     -1.13658
      0.8765



## 独立性の検定

独立性の検定は，2 つのカテゴリー変数が独立であるか（関連があるか）を検定する。

ここでは，前節と同じピアソンの $\chi^2$ 検定 と，対数尤度比検定（$G^2$ 検定）を提示する。

利用する関数は，前節と同じ `PowerDivergenceTest()` である。引数として二重集計表を与える場合と，2 つのベクトルを与える場合に対応している。

しかし，2 つのベクトルを与える場合には完全対応していないので，二重集計表を与えて使用する。

### ピアソンの $\chi^2$ 検定

関数定義<br>
`PowerDivergenceTest(x; lambda=1.0)`

■ 使用例　2 × 2 分割表の場合


```julia
x = [12 35
     43 56]
```




    2×2 Matrix{Int64}:
     12  35
     43  56




```julia
result = PowerDivergenceTest(x, lambda=1.0)
```




    Pearson's Chi-square Test
    -------------------------
    Population details:
        parameter of interest:   Multinomial Probabilities
        value under h_0:         [0.12127, 0.255442, 0.200647, 0.42264]
        point estimate:          [0.0821918, 0.294521, 0.239726, 0.383562]
        95% confidence interval: [(0.0, 0.1716), (0.2123, 0.384), (0.1575, 0.3292), (0.3014, 0.473)]
    
    Test summary:
        outcome with 95% confidence: reject h_0
        one-sided p-value:           0.0370
    
    Details:
        Sample size:        146
        statistic:          4.350164943588549
        degrees of freedom: 1
        residuals:          [-1.35593, 0.934264, 1.05414, -0.726324]
        std. residuals:     [-2.0857, 2.0857, 2.0857, -2.0857]




■ 個別に表示できる統計量

- 概要

前節で定義した `chisq_test()` もそのまま使える。


```julia
chisq_test(x)
```

    χ-sq. = 4.350164943588549,  df = 1,  p value = 0.037005362019413034


- $p$ 値　この検定では `tail=:both`，`tail=:left` は使用してはいけない<br>
上に示した結果の一覧表示で `"one-sided p-value: 0.0370"` とあるのは，この検定が `"one-sided"` はないので誤った記述である。棄却域は $\chi^2$ 分布の右側にしかないが，本来この検定は意味的に両側検定である（両側検定，片側検定という区分分け自体が不要である）。


```julia
pvalue(result)
```




    0.037005362019413034




```julia
pvalue(result, tail=:right)
```




    0.037005362019413034



- イエーツの連続性の補正による $p$ 値

2×2 分割表の場合，`PowerDivergenceTest()` で得られる検定統計量はイエーツの連続性の補正をしないものである。

イエーツの連続性の補正をする場合には，以下の関数を定義しておくとよい。


```julia
using Distributions
function yates(x)
    result = PowerDivergenceTest(x, lambda=1.0)
    n = sum(x)
    a, c, b, d = x
    stat = n*max(0, abs(a*d - b*c) - 0.5n)^2 / ((a+b)*(c+d)*(a+c)*(b+d))
    p = ccdf(Chisq(1), stat)
    println("corrected χ-sq. = $stat,  df = 1,  p value = $p")
end;

yates(x)
```

    corrected χ-sq. = 3.621119907386832,  df = 1,  p value = 0.05705045741699577


- 信頼区間　信頼区間は分割表の各セルの確率の信頼区間である。<br>
この検定では，`tail=:left`，`tail=:right` は使用してはいけない（`pvalue()` の場合と違うので注意が必要である）。


```julia
confint(result)
```




    4-element Vector{Tuple{Float64, Float64}}:
     (0.0, 0.17163425153174042)
     (0.2123287671232877, 0.38396301865502813)
     (0.15753424657534246, 0.3291684981070829)
     (0.3013698630136986, 0.47300411454543906)




```julia
confint(result, tail=:both)
```




    4-element Vector{Tuple{Float64, Float64}}:
     (0.0, 0.17163425153174042)
     (0.2123287671232877, 0.38396301865502813)
     (0.15753424657534246, 0.3291684981070829)
     (0.3013698630136986, 0.47300411454543906)



- lambda　$\lambda$


```julia
result.lambda
```




    1.0



- `n`　サンプルサイズ


```julia
result.n
```




    146



- `observed`　観察度数分布


```julia
result.observed
```




    2×2 Matrix{Int64}:
     12  35
     43  56



- `thetahat`　観察度数の確率<br>
`result.observed / result.n`


```julia
result.thetahat
```




    4-element Vector{Float64}:
     0.0821917808219178
     0.2945205479452055
     0.23972602739726026
     0.3835616438356164



- `theta0`　帰無仮説の下での観察度数の確率（等確率）<br>
`ones(length(result.observed)) / length(result.observed)`


```julia
round.(result.theta0, digits=5)
```




    4-element Vector{Float64}:
     0.12127
     0.25544
     0.20065
     0.42264



- `expected`　帰無仮説の下での観察度数の期待値（同じ値）<br>
`result.n * result.theta0`


```julia
round.(result.expected, digits=5)
```




    2×2 Matrix{Float64}:
     17.7055  29.2945
     37.2945  61.7055



- `stat`　検定統計量（$\chi^2$ 分布にしたがう）<br>
`sum((result.observed - result.expected).^2 ./ result.expected)`


```julia
result.stat
```




    4.350164943588549



- `df`　$\chi^2$ 分布の自由度<br>
`length(result.observed) - 1`


```julia
result.df
```




    1



- `residuals`　残差<br>
`(result.observed - result.expected) ./ sqrt.(result.expected)`


```julia
Base.print_matrix(stdout, round.(result.residuals, digits=7), "", "   ", "\n")
```

    -1.3559332    1.0541416
     0.934264    -0.7263238


- `stdresiduals`　標準化残差<br>
`V = result.n .* result.theta0 .* (1 .- result.theta0)`<br>
`(result.observed - result.expected) ./ sqrt.(V)`


```julia
Base.print_matrix(stdout, round.(result.stdresiduals, digits=7), "", "   ", "\n")
```

    -2.0857049    2.0857049
     2.0857049   -2.0857049


- 残差分析

残差分析の結果は `PowerDivergenceTest(x, lambda=1.0)` が返す `std.residuals` を使用する。

対応する $p$ 値を表示するために，以下の関数を用意しておくとよい。


```julia
using Distributions
function residual_analysis(x)
    result = PowerDivergenceTest(x, lambda=1.0);
    nrows, ncols = size(x)
    p = 2ccdf.(Normal(), abs.(result.stdresiduals))
    Base.print_matrix(stdout, round.(p, digits=7), "", "   ", "\n")
end

residual_analysis(x)
```

    0.0370054   0.0370054
    0.0370054   0.0370054


■ 使用例2　文字列ベクトルを与えて検定する


```julia
answer = ["Yes", "Yes", "No", "No", "No", "Yes", "No", "Yes", "Yes", "No",
          "No", "Yes", "Yes", "No", "Yes", "Yes", "No", "No", "No", "No"]
status = ["Hi", "Lo", "Med", "Med", "Lo", "Hi", "Lo", "Hi", "Lo", "Lo",
          "Med", "Med", "Lo", "Med", "Med", "Lo", "Lo", "Hi", "Lo", "Med"]

using FreqTables
y = freqtable(answer, status)
```




    2×3 Named Matrix{Int64}
    Dim1 ╲ Dim2 │  Hi   Lo  Med
    ────────────┼──────────────
    No          │   1    5    5
    Yes         │   3    4    2



- 概要


```julia
chisq_test(y)
```

    χ-sq. = 2.2190155523488855,  df = 2,  p value = 0.32972121777778757


- 残差分析の $p$ 値


```julia
residual_analysis(y)
```

    0.1775299   0.9639693   0.2785029
    0.1775299   0.9639693   0.2785029


### 対数尤度比検定（$G^2$ 検定）

関数定義<br>
`PowerDivergenceTest(x, lambda=0.0)`

一般的には，$\chi^2$ 検定より $G^2$ 検定のほうが検定力は高い（$p$ 値が小さい）。

 ■ 使用例


```julia
x = [10 3; 4 12]
```




    2×2 Matrix{Int64}:
     10   3
      4  12




```julia
result = PowerDivergenceTest(x, lambda=0.0)
```




    Multinomial Likelihood Ratio Test
    ---------------------------------
    Population details:
        parameter of interest:   Multinomial Probabilities
        value under h_0:         [0.216409, 0.26635, 0.231867, 0.285375]
        point estimate:          [0.344828, 0.137931, 0.103448, 0.413793]
        95% confidence interval: [(0.1724, 0.537), (0.0, 0.3301), (0.0, 0.2957), (0.2414, 0.606)]
    
    Test summary:
        outcome with 95% confidence: reject h_0
        one-sided p-value:           0.0044
    
    Details:
        Sample size:        29
        statistic:          8.1280145470097
        degrees of freedom: 1
        residuals:          [1.48658, -1.33999, -1.43618, 1.29455]
        std. residuals:     [2.7828, -2.7828, -2.7828, 2.7828]




■ 個別に表示できる統計量

- 概要

前節で定義した G2_test() もそのまま使える。


```julia
G2_test(x) # 対数尤度比に基づく検定（G2検定）
```

    G-sq. = 8.1280145470097,  df = 1,  p value = 0.00435864516471826


- $p$ 値　この検定では `tail=:both`，`tail=:left` は使用してはいけない<br>
上に示した結果の一覧表示で `"one-sided p-value: 0.0044"` とあるのは，この検定が `"one-sided"` はないので誤った記述である。棄却域は $\chi^2$ 分布の右側にしかないが，本来この検定は意味的に両側検定である（両側検定，片側検定という区分分け自体が不要である）。


```julia
pvalue(result)
```




    0.00435864516471826




```julia
pvalue(result, tail=:right)
```




    0.00435864516471826



- 信頼区間　信頼区間は分割表の各セルの確率の信頼区間である。<br>
この検定では，`tail=:left`，`tail=:right` は使用してはいけない（`pvalue()` の場合と違うので注意が必要である）。


```julia
confint(result)
```




    4-element Vector{Tuple{Float64, Float64}}:
     (0.1724137931034483, 0.5370409523965961)
     (0.0, 0.3301444006724581)
     (0.0, 0.2956616420517684)
     (0.24137931034482757, 0.6060064696379754)




```julia
confint(result, tail=:both)
```




    4-element Vector{Tuple{Float64, Float64}}:
     (0.1724137931034483, 0.5370409523965961)
     (0.0, 0.3301444006724581)
     (0.0, 0.2956616420517684)
     (0.24137931034482757, 0.6060064696379754)



- lambda　$\lambda$


```julia
result.lambda
```




    0.0



- `n`　サンプルサイズ


```julia
result.n
```




    29



- `observed`　観察度数分布


```julia
result.observed
```




    2×2 Matrix{Int64}:
     10   3
      4  12



- `thetahat`　観察度数の確率<br>
`result.observed / result.n`


```julia
result.thetahat
```




    4-element Vector{Float64}:
     0.3448275862068966
     0.13793103448275862
     0.10344827586206896
     0.41379310344827586



- `theta0`　帰無仮説の下での観察度数の確率（等確率）<br>
`ones(length(result.observed)) / length(result.observed)`


```julia
round.(result.theta0, digits=5)
```




    4-element Vector{Float64}:
     0.21641
     0.26635
     0.23187
     0.28537



- `expected`　帰無仮説の下での観察度数の期待値（同じ値）<br>
`result.n * result.theta0`


```julia
round.(result.expected, digits=5)
```




    2×2 Matrix{Float64}:
     6.27586  6.72414
     7.72414  8.27586



- `stat`　検定統計量（$\chi^2$ 分布にしたがう）<br>
`sum((result.observed - result.expected).^2 ./ result.expected)`


```julia
result.stat
```




    8.1280145470097



- `df`　$\chi^2$ 分布の自由度<br>
`length(result.observed) - 1`


```julia
result.df
```




    1



- `residuals`　残差。ピアソンの $\chi^2$ 検定と同じである<br>
`(result.observed - result.expected) ./ sqrt.(result.expected)`


```julia
Base.print_matrix(stdout, round.(result.residuals, digits=7), "", "   ", "\n")
```

     1.4865827   -1.4361753
    -1.3399875    1.2945509


- `stdresiduals`　標準化残差。ピアソンの $\chi^2$ 検定と同じである<br><br>
`V = result.n .* result.theta0 .* (1 .- result.theta0)`<br>
`(result.observed - result.expected) ./ sqrt.(V)`


```julia
Base.print_matrix(stdout, round.(result.stdresiduals, digits=7), "", "   ", "\n")
```

     2.7827964   -2.7827964
    -2.7827964    2.7827964


■ 分割表のマス目に 0 がある場合の $G^2$ 検定 

`PowerDivergenceTest()` は　`lambda=0.0` を指定することで対数尤度比に基づく検定（$G^2$ 検定）ができるが，分割表のマス目のうちに 0 であるものが 1 つでもある場合には正しい結果が得られない。


```julia
z = [4 5 2 0
     0 7 6 1
     1 0 3 1]
result = PowerDivergenceTest(z, lambda=0.0);
p = pvalue(result)
println("Chisq. = $(result.stat),  df = $(result.df),  p value = $p")
```

    Chisq. = NaN,  df = 6,  p value = NaN


実は `lambda` を 0.0 に近づけていくと $G^2$ 検定になるということなので，たとえば `lambda=0.0000001` では以下のようになる。


```julia
result = PowerDivergenceTest(z, lambda=0.000000001);
p = pvalue(result)
println("Chisq. = $(result.stat),  df = $(result.df),  p value = $p")
```

    Chisq. = 15.364590917511304,  df = 6,  p value = 0.017602889013051494


次に示す `trueG2_test()` は前節で定義した関数と同じように $G^2$ 検定を実施するが，分割表のマス目のうちに 0 があるような場合でも，正確に `lambda=0.0` にした場合の，正しい答えを返す。


```julia
using Distributions
function trueG2_test(x; correct=false)
    # セルに 0 があっても正しい答えを出す
    # correct=true で，連続性の補正も行うことができる
    ln(n) = sum(n .== 0 ? 0 : n .* log(n) for n in vcat(n...))
    nrows, ncols = size(x)
    n = sum(x) # 全サンプルサイズ
    n1 = sum(x, dims=2) # 行和
    n2 = sum(x, dims=1) # 列和
    G2 = 2*(ln(x) - ln(n1) - ln(n2) + ln(n)) # G 統計量
    correct && (G2 /= 1 + (n * sum(1 ./ n1) - 1) * (n * sum(1 ./ n2) - 1) / (6n * nrows * ncols)) # 連続性の補正
    df = (nrows - 1) * (ncols - 1) # G の自由度
    p = ccdf(Chisq(df), G2)
    name = correct ? "corrected G-sq." : "G-sq."
    println("$name = $G2,  df = $df,  p value = $p")
end

trueG2_test(z)
```

    G-sq. = 15.364591286599591,  df = 6,  p value = 0.01760288650305146


また，ピアソンの $\chi^2$ 検定では 2×2 分割表の場合にしか連続性の補正は行えないが，$G^2$ 検定は分割表の大きさに関わらず，連続性の補正を行うことができる。

上に示した関数 `trueG2_test()` で `correct=true` を指定すればよい。


```julia
trueG2_test(z)
```

    G-sq. = 15.364591286599591,  df = 6,  p value = 0.01760288650305146



```julia
trueG2_test(z, correct=true) # 連続性の補正
```

    corrected G-sq. = 13.776490649307341,  df = 6,  p value = 0.03223501559558125


## パワーダイバージェンス検定

関数定義<br>
`PowerDivergenceTest(x; lambda = 1.0, theta0 = ones(length(x))/length(x))`

パワーダイバージェンス検定（Power divergence test）は前節の ピアソンの $\chi^2$，対数尤度比検定（$G^2$ 検定）などを包含する，一般化した検定である。

$$
\frac{2}{\lambda(\lambda+1)} \sum_{i=1}^I \sum_{j=1}^J n_{ij} \left [\left ( \frac{n_{ij}}{\hat{n}_{ij}}\right )^\lambda  - 1\right ]
$$

ここで，lambda($\lambda$) と適用される検定統計量の対応は以下のようになる。

lambda   | 適用される検定統計量
:-----   | :-----
λ = 1    | ピアソンの $\chi^2$ 検定統計量
λ → 0    | 対数尤度比検定統計量 $G^2$ に収束
λ → −1   | 最小判別情報量統計量に収束(Gokhale and Kullback, 1978)
λ = −2   | 修正された $\chi^2$ 検統計量(Neyman, 1949)
λ = −1/2 | Freeman-Tukey 統計量(Freeman and Tukey, 1950)


```julia
using Plots
x = [2 4 3; 1 5 3; 4 2 3];
lambdas = collect(-2:0.1:1)
stats = Float64[]
for lambda in lambdas
    result = PowerDivergenceTest(x, lambda=lambda)
    append!(stats, result.stat)
end
plot(lambdas, stats, xlabel="λ", ylabel="test statistic",
     grid=false, tick_direction=:out, tickfont=("Times", 6),
        size=(340, 230), label="")
```




<?xml version="1.0" encoding="utf-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="340" height="230" viewBox="0 0 1360 920">
<defs>
  <clipPath id="clip550">
    <rect x="0" y="0" width="1360" height="920"/>
  </clipPath>
</defs>
<path clip-path="url(#clip550)" d="M0 920 L1360 920 L1360 -5.32907e-14 L0 -5.32907e-14  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip551">
    <rect x="272" y="0" width="953" height="920"/>
  </clipPath>
</defs>
<path clip-path="url(#clip550)" d="M189.502 757.381 L1312.76 757.381 L1312.76 47.2441 L189.502 47.2441  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip552">
    <rect x="189" y="47" width="1124" height="711"/>
  </clipPath>
</defs>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="189.502,757.381 1312.76,757.381 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="221.292,757.381 221.292,776.279 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="574.516,757.381 574.516,776.279 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="927.741,757.381 927.741,776.279 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1280.97,757.381 1280.97,776.279 "/>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 221.292, 806.258)" x="221.292" y="806.258">−2</text>
</g>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 574.516, 806.258)" x="574.516" y="806.258">−1</text>
</g>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 927.741, 806.258)" x="927.741" y="806.258">0</text>
</g>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 1280.97, 806.258)" x="1280.97" y="806.258">1</text>
</g>
<path clip-path="url(#clip550)" d="M752.02 829.965 L768.475 873.92 L762.269 873.92 L752.275 847.566 L739.989 873.92 L733.782 873.92 L749.41 839.736 L747.055 833.434 Q745.559 829.424 742.153 829.424 L739.098 829.424 L739.098 824.395 L742.821 824.458 Q750.015 824.554 752.02 829.965 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="189.502,757.381 189.502,47.2441 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="189.502,654.281 170.604,654.281 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="189.502,523.85 170.604,523.85 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="189.502,393.419 170.604,393.419 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="189.502,262.989 170.604,262.989 "/>
<polyline clip-path="url(#clip550)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="189.502,132.558 170.604,132.558 "/>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 134.43, 667.281)" x="134.43" y="667.281">3.4</text>
</g>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 134.43, 536.85)" x="134.43" y="536.85">3.6</text>
</g>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 134.43, 406.419)" x="134.43" y="406.419">3.8</text>
</g>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 134.43, 275.989)" x="134.43" y="275.989">4.0</text>
</g>
<g clip-path="url(#clip550)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 134.43, 145.558)" x="134.43" y="145.558">4.2</text>
</g>
<path clip-path="url(#clip550)" d="M39.7336 590.483 L49.855 590.483 L49.855 578.42 L54.4065 578.42 L54.4065 590.483 L73.7583 590.483 Q78.1188 590.483 79.3601 589.305 Q80.6014 588.096 80.6014 584.435 L80.6014 578.42 L85.503 578.42 L85.503 584.435 Q85.503 591.215 82.9885 593.793 Q80.4422 596.371 73.7583 596.371 L54.4065 596.371 L54.4065 600.668 L49.855 600.668 L49.855 596.371 L39.7336 596.371 L39.7336 590.483 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M66.2149 540.226 L69.0795 540.226 L69.0795 567.152 Q75.1269 566.771 78.3097 563.524 Q81.4608 560.246 81.4608 554.421 Q81.4608 551.047 80.6332 547.896 Q79.8057 544.713 78.1506 541.594 L83.6888 541.594 Q85.0256 544.745 85.7258 548.055 Q86.426 551.366 86.426 554.771 Q86.426 563.301 81.4608 568.298 Q76.4955 573.264 68.0291 573.264 Q59.2763 573.264 54.1519 568.553 Q48.9957 563.81 48.9957 555.79 Q48.9957 548.596 53.6426 544.427 Q58.2578 540.226 66.2149 540.226 M64.4961 546.082 Q59.69 546.146 56.8255 548.787 Q53.9609 551.397 53.9609 555.726 Q53.9609 560.628 56.73 563.588 Q59.4991 566.516 64.528 566.962 L64.4961 546.082 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M50.9054 507.888 L56.4435 507.888 Q55.1704 510.37 54.5338 513.044 Q53.8972 515.718 53.8972 518.582 Q53.8972 522.943 55.234 525.139 Q56.5708 527.303 59.2444 527.303 Q61.2815 527.303 62.4591 525.744 Q63.605 524.184 64.6553 519.473 L65.1009 517.468 Q66.4377 511.23 68.8885 508.62 Q71.3075 505.978 75.668 505.978 Q80.6332 505.978 83.5296 509.925 Q86.426 513.84 86.426 520.715 Q86.426 523.579 85.8531 526.698 Q85.312 529.786 84.198 533.223 L78.1506 533.223 Q79.8375 529.977 80.6969 526.826 Q81.5244 523.675 81.5244 520.587 Q81.5244 516.45 80.124 514.222 Q78.6917 511.994 76.1136 511.994 Q73.7264 511.994 72.4533 513.617 Q71.1801 515.208 70.0025 520.651 L69.5251 522.688 Q68.3792 528.131 66.0239 530.55 Q63.6368 532.969 59.4991 532.969 Q54.4702 532.969 51.7329 529.404 Q48.9957 525.839 48.9957 519.282 Q48.9957 516.036 49.4731 513.171 Q49.9505 510.307 50.9054 507.888 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M39.7336 490.859 L49.855 490.859 L49.855 478.796 L54.4065 478.796 L54.4065 490.859 L73.7583 490.859 Q78.1188 490.859 79.3601 489.682 Q80.6014 488.472 80.6014 484.812 L80.6014 478.796 L85.503 478.796 L85.503 484.812 Q85.503 491.592 82.9885 494.17 Q80.4422 496.748 73.7583 496.748 L54.4065 496.748 L54.4065 501.045 L49.855 501.045 L49.855 496.748 L39.7336 496.748 L39.7336 490.859 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M50.9054 427.648 L56.4435 427.648 Q55.1704 430.131 54.5338 432.804 Q53.8972 435.478 53.8972 438.342 Q53.8972 442.703 55.234 444.899 Q56.5708 447.063 59.2444 447.063 Q61.2815 447.063 62.4591 445.504 Q63.605 443.944 64.6553 439.234 L65.1009 437.228 Q66.4377 430.99 68.8885 428.38 Q71.3075 425.738 75.668 425.738 Q80.6332 425.738 83.5296 429.685 Q86.426 433.6 86.426 440.475 Q86.426 443.339 85.8531 446.459 Q85.312 449.546 84.198 452.984 L78.1506 452.984 Q79.8375 449.737 80.6969 446.586 Q81.5244 443.435 81.5244 440.348 Q81.5244 436.21 80.124 433.982 Q78.6917 431.754 76.1136 431.754 Q73.7264 431.754 72.4533 433.377 Q71.1801 434.969 70.0025 440.411 L69.5251 442.448 Q68.3792 447.891 66.0239 450.31 Q63.6368 452.729 59.4991 452.729 Q54.4702 452.729 51.7329 449.164 Q48.9957 445.599 48.9957 439.043 Q48.9957 435.796 49.4731 432.932 Q49.9505 430.067 50.9054 427.648 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M39.7336 410.62 L49.855 410.62 L49.855 398.557 L54.4065 398.557 L54.4065 410.62 L73.7583 410.62 Q78.1188 410.62 79.3601 409.442 Q80.6014 408.233 80.6014 404.572 L80.6014 398.557 L85.503 398.557 L85.503 404.572 Q85.503 411.352 82.9885 413.93 Q80.4422 416.508 73.7583 416.508 L54.4065 416.508 L54.4065 420.805 L49.855 420.805 L49.855 416.508 L39.7336 416.508 L39.7336 410.62 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M67.5835 374.654 Q67.5835 381.751 69.2068 384.489 Q70.83 387.226 74.7449 387.226 Q77.8641 387.226 79.7102 385.189 Q81.5244 383.12 81.5244 379.587 Q81.5244 374.717 78.0869 371.789 Q74.6176 368.829 68.8885 368.829 L67.5835 368.829 L67.5835 374.654 M65.1645 362.972 L85.503 362.972 L85.503 368.829 L80.0921 368.829 Q83.3386 370.834 84.8982 373.826 Q86.426 376.818 86.426 381.147 Q86.426 386.621 83.3705 389.868 Q80.2831 393.082 75.1269 393.082 Q69.1113 393.082 66.0557 389.072 Q63.0002 385.03 63.0002 377.041 L63.0002 368.829 L62.4273 368.829 Q58.3851 368.829 56.1889 371.502 Q53.9609 374.144 53.9609 378.95 Q53.9609 382.006 54.693 384.902 Q55.425 387.799 56.8891 390.472 L51.4783 390.472 Q50.237 387.258 49.6322 384.234 Q48.9957 381.21 48.9957 378.346 Q48.9957 370.611 53.006 366.792 Q57.0164 362.972 65.1645 362.972 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M39.7336 345.117 L49.855 345.117 L49.855 333.054 L54.4065 333.054 L54.4065 345.117 L73.7583 345.117 Q78.1188 345.117 79.3601 343.939 Q80.6014 342.729 80.6014 339.069 L80.6014 333.054 L85.503 333.054 L85.503 339.069 Q85.503 345.849 82.9885 348.427 Q80.4422 351.005 73.7583 351.005 L54.4065 351.005 L54.4065 355.302 L49.855 355.302 L49.855 351.005 L39.7336 351.005 L39.7336 345.117 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M49.855 325.351 L49.855 319.495 L85.503 319.495 L85.503 325.351 L49.855 325.351 M35.9778 325.351 L35.9778 319.495 L43.3938 319.495 L43.3938 325.351 L35.9778 325.351 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M50.9054 284.515 L56.4435 284.515 Q55.1704 286.998 54.5338 289.671 Q53.8972 292.345 53.8972 295.209 Q53.8972 299.57 55.234 301.766 Q56.5708 303.931 59.2444 303.931 Q61.2815 303.931 62.4591 302.371 Q63.605 300.811 64.6553 296.101 L65.1009 294.095 Q66.4377 287.857 68.8885 285.247 Q71.3075 282.605 75.668 282.605 Q80.6332 282.605 83.5296 286.552 Q86.426 290.467 86.426 297.342 Q86.426 300.207 85.8531 303.326 Q85.312 306.413 84.198 309.851 L78.1506 309.851 Q79.8375 306.604 80.6969 303.453 Q81.5244 300.302 81.5244 297.215 Q81.5244 293.077 80.124 290.849 Q78.6917 288.621 76.1136 288.621 Q73.7264 288.621 72.4533 290.244 Q71.1801 291.836 70.0025 297.278 L69.5251 299.315 Q68.3792 304.758 66.0239 307.177 Q63.6368 309.596 59.4991 309.596 Q54.4702 309.596 51.7329 306.031 Q48.9957 302.466 48.9957 295.91 Q48.9957 292.663 49.4731 289.799 Q49.9505 286.934 50.9054 284.515 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M39.7336 267.487 L49.855 267.487 L49.855 255.424 L54.4065 255.424 L54.4065 267.487 L73.7583 267.487 Q78.1188 267.487 79.3601 266.309 Q80.6014 265.1 80.6014 261.439 L80.6014 255.424 L85.503 255.424 L85.503 261.439 Q85.503 268.219 82.9885 270.797 Q80.4422 273.375 73.7583 273.375 L54.4065 273.375 L54.4065 277.672 L49.855 277.672 L49.855 273.375 L39.7336 273.375 L39.7336 267.487 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M49.855 247.721 L49.855 241.865 L85.503 241.865 L85.503 247.721 L49.855 247.721 M35.9778 247.721 L35.9778 241.865 L43.3938 241.865 L43.3938 247.721 L35.9778 247.721 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip550)" d="M51.2237 203.957 L56.6982 203.957 Q55.3295 206.44 54.6611 208.954 Q53.9609 211.437 53.9609 213.983 Q53.9609 219.68 57.5894 222.831 Q61.186 225.982 67.7108 225.982 Q74.2357 225.982 77.8641 222.831 Q81.4608 219.68 81.4608 213.983 Q81.4608 211.437 80.7924 208.954 Q80.0921 206.44 78.7235 203.957 L84.1344 203.957 Q85.2802 206.408 85.8531 209.05 Q86.426 211.66 86.426 214.62 Q86.426 222.672 81.3653 227.415 Q76.3045 232.157 67.7108 232.157 Q58.9898 232.157 53.9927 227.383 Q48.9957 222.577 48.9957 214.238 Q48.9957 211.532 49.5686 208.954 Q50.1097 206.376 51.2237 203.957 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><polyline clip-path="url(#clip552)" style="stroke:#009af9; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="221.292,67.3423 256.614,117.948 291.937,165.865 327.259,211.207 362.582,254.082 397.904,294.591 433.227,332.829 468.549,368.887 503.872,402.849 539.194,434.794 574.516,464.796 609.839,492.925 645.161,519.247 680.484,543.822 715.806,566.709 751.129,587.96 786.451,607.626 821.774,625.753 857.096,642.385 892.419,657.562 927.741,671.322 963.064,683.698 998.386,694.723 1033.71,704.427 1069.03,712.835 1104.35,719.972 1139.68,725.859 1175,730.518 1210.32,733.965 1245.64,736.215 1280.97,737.283 "/>
</svg>




$\chi^2$ 分布で近似する場合には λ ≒ 2/3 のときに最も近似効率が高いとされる。

`PowerDivergenceTest()` での `lambda` は実数で指定しなければならない(`lambda=1` ではなく，`lambda=1.0` と指定する）。

- `lambda=1.0` でピアソンの $\chi^2$ 検定を行う。


```julia
result1 = PowerDivergenceTest([10 3; 4 12], lambda=1.0)
p = pvalue(result1)
println("χ-sq. = $(result1.stat),  df = $(result1.df),  p value = $p")
```

    χ-sq. = 7.743956043956044,  df = 1,  p value = 0.005389260671694263



```julia
chisq_test([10 3; 4 12]) # 上の例と同じである
```

    χ-sq. = 7.743956043956044,  df = 1,  p value = 0.005389260671694263


- `lambda=0.0` で，対数尤度比に基づく $G^2$ 検定を行う。


```julia
result2 = PowerDivergenceTest([10 3; 4 12], lambda=0.0)
p = pvalue(result2)
println("G-sq. = $(result2.stat),  df = $(result2.df),  p value = $p")
```

    G-sq. = 8.1280145470097,  df = 1,  p value = 0.00435864516471826



```julia
G2_test([10 3; 4 12]) # 上の例と同じである
```

    G-sq. = 8.1280145470097,  df = 1,  p value = 0.00435864516471826


## フィッシャーの正確検定

関数定義<br>
`FisherExactTest(a::Integer, b::Integer, c::Integer, d::Integer)`

`FisherExactTest()` で用意されているのは 2×2 分割表の場合だけである。4 つのセルの度数を指定する。

帰無仮説は何通りかの表現法があるが，同じことを意味している。

- 2 要因が独立である
- 2 群の比率が等しい $\displaystyle \frac{a}{a+b} = \frac{c}{c+d}$
- オッズ比が 1 である $\displaystyle \frac{a/c}{b/d} = \frac{a\cdot d}{b\cdot c}=1$

■ 使用例


```julia
result = FisherExactTest(10, 3, 4, 12)
```




    Fisher's exact test
    -------------------
    Population details:
        parameter of interest:   Odds ratio
        value under h_0:         1.0
        point estimate:          9.06784
        95% confidence interval: (1.422, 80.35)
    
    Test summary:
        outcome with 95% confidence: reject h_0
        two-sided p-value:           0.0146
    
    Details:
        contingency table:
            10   3
             4  12




■ 個別に表示できる統計量

- $p$ 値


```julia
pvalue(result) # デフォールトで両側検定の p 値
```




    0.014589609220157725




```julia
pvalue(result, tail=:both) # 両側検定の p 値
```




    0.014589609220157725




```julia
pvalue(result, tail=:left) # 片側検定の p 値
```




    0.9994164940233701




```julia
pvalue(result, tail=:right) # 片側検定の p 値
```




    0.007294804610078863



`FisherExactTest()` の両側検定の $p$ 値は該当する片側確率を 2 倍するものである。

上の例では，0.014589609220157725 = 2 × 0.007294804610078863 になっている。


```julia
pvalue(result, method=:central) # 両側検定の p 値（デフォルト）
```




    0.014589609220157725



このような計算方法は R や matlab などの他の統計ソフトと違う。同じ結果を得るためには，オプション設定 `method=:minlike` としなければならない。


```julia
pvalue(result, method=:minlike)
```




    0.009220570313398513




```julia
using RCall # R で計算すると以下のようになる
R"""
options(digits=15)
x = matrix(c(10, 3, 4, 12), 2)
fisher.test(x)$p.value
"""
```




    RObject{RealSxp}
    [1] 0.00922057031339851




- ω　オッズ比


```julia
result.ω
```




    9.067840887689634



- `confint`　オッズ比の信頼区間


```julia
confint(result)
```




    (1.4222662898175877, 80.34790877482563)



信頼率は，`level` で指定できる（`0 < level < 1`）


```julia
confint(result, level=0.95)
```




    (1.4222662898175877, 80.34790877482563)



■ オッズ比の $p$ 値と信頼区間について

オッズ比（$OR$）の $p$ 値，信頼区間には何通りかの方法がある。

`FisherExactTest()` は，R の `fisher.test()` と同じく，条件付き最尤推定量を求める。　[外部リンク：Fisherの正確検定](https://oku.edu.mie-u.ac.jp/~okumura/stat/fishertest.html)

一方，広く使われているのは条件なしの最尤推定量（Wald のオッズ比）で，以下の関数で計算できる。　[外部リンク：統計学入門-第3章](http://www.snap-tck.com/room04/c01/stat/stat03/stat0304_2.html#note05)


```julia
using Distributions
function oddsratio(a, b, c, d; conf=0.95, correct=false)
    if correct || a*b*c*d == 0
        a, b, c, d = a+0.5, b+0.5, c+0.5, d+0.5
    end
    or = a*d / (b*c)
    LCL, UCL = or .* exp.([1, -1] .* quantile(Normal(), 0.5 - conf/2) * sqrt(1/a+1/b+1/c+1/d))
    println("オッズ比 = $or")
    println("$(Int(100conf))% 信頼区間  [$LCL, $UCL]")
end;
```


```julia
oddsratio(10, 3, 4, 12)
```

    オッズ比 = 10.0
    95% 信頼区間  [1.7975962537192371, 55.62984446206951]


R での実行結果を添付しておく。


```julia
using RCall
R"fisher.test(matrix(c(10, 3, 4, 12), 2))"
```




    RObject{VecSxp}
    
    	Fisher's Exact Test for Count Data
    
    data:  matrix(c(10, 3, 4, 12), 2)
    p-value = 0.0092205703134
    alternative hypothesis: true odds ratio is not equal to 1
    95 percent confidence interval:
      1.42227515556236 80.34058365829780
    sample estimates:
          odds ratio 
    9.06776007785795 
    




## 二項検定

二項検定は `BinomialTest()` で行う。

関数定義1<br>
`BinomialTest(x::Integer, n::Integer, p::Real = 0.5)`<br>
成功母比率 `p` の試行を `n` 回行い，`x` 回成功したとき，母比率が特定の値（デフォルトでは 0.5）であるかどうか検定する。

関数定義2<br>
`BinomialTest(x::AbstractVector{Bool}, p::Real = 0.5)`<br>
成功のとき 1，不成功のとき 0 の `Bool` 試行結果ベクトル `x` と母比率 `p` を与える場合。<br>

たとえば，20回の実験結果が `x = Bool[1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0]` の場合，関数定義2 では ``BinomialTest(x)` と書く。
成功が 12 回なので， 関数定義1 で書くと `BinomialTest(12, 20)` とも書ける。

■ 使用例



```julia
result = BinomialTest(12, 20)
```




    Binomial test
    -------------
    Population details:
        parameter of interest:   Probability of success
        value under h_0:         0.5
        point estimate:          0.6
        95% confidence interval: (0.3605, 0.8088)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.5034
    
    Details:
        number of observations: 20
        number of successes:    12




■ 個別に表示できる統計量

概要

- $p$ 値

デフォルトでは両側検定の $p$ 値が表示される。


```julia
pvalue(result, tail=:left)
```




    0.8684120178222656




```julia
pvalue(result, tail=:right)
```




    0.2517223358154298




```julia
pvalue(result, tail=:both)
```




    0.5034446716308596



なお，両側検定の $p$ 値は該当する片側検定の $p$ 値を 2 倍したものであり，R や matlab などの他の統計ソフトとは違う。

計算方法により結果が違うのは，「母比率が 0.5 以外の両側検定」の場合に限られる。

以下の例，x=18, n=24, p=0.68 の場合，$p$ 値は 0.6206975448201958 が表示されるが，R では 0.5205908910845283 となる。


```julia
result2 = BinomialTest(18, 24, 0.68); # p=0.68 の場合。数値だけ指定するので注意。
pvalue(result2, tail=:both)
```




    0.6206975448201958




```julia
using RCall
R"""
options(digits=16)
binom.test(18, 24, 0.68)$p.value
"""
```




    RObject{RealSxp}
    [1] 0.5205908910845283




`BinomialTest()` では，$n = 18,..., 24$ の二項分布の確率の合計が 0.3103487724100979 で，


```julia
pvalue(result, tail=:right)
```




    0.2517223358154298



その 2 倍が両側 $p$ 値になっている。


```julia
2 * pvalue(result, tail=:right)
```




    0.5034446716308596



R などでは，まず $n = 18,...,24$ を右側の棄却域とするところまでは同じであるが，もう一方の側の棄却域を次のようにして決める。

$x = 0, 1, ...$ と順に見ていき，観察値 18 のときの確率より小さい最大の $n$ まで，図でいえば $x = 0, ..., 14$ までを棄却域とする。

それぞれの棄却域における確率の合計を両側確率とする。


```julia
using Plots, Distributions
n = 24
p = 0.68
p_value = Float64[]
col = [i <= 14 || i >= 18 ? :red : :blue for i in 0:24]
for x = 0:n
    probability = pdf(Binomial(n, p), x)
    append!(p_value, probability)
end
bar(0:n, p_value, grid=false, tick_direction=:out,
    xlabel= "x", ylabel="probability", color=col, alpha=0.4,
    tickfont=("Times", 6), size=(340, 230), label="")
```




<?xml version="1.0" encoding="utf-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="340" height="230" viewBox="0 0 1360 920">
<defs>
  <clipPath id="clip640">
    <rect x="0" y="0" width="1360" height="920"/>
  </clipPath>
</defs>
<path clip-path="url(#clip640)" d="M0 920 L1360 920 L1360 -5.32907e-14 L0 -5.32907e-14  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip641">
    <rect x="272" y="0" width="953" height="920"/>
  </clipPath>
</defs>
<path clip-path="url(#clip640)" d="M209.079 757.381 L1312.76 757.381 L1312.76 47.2441 L209.079 47.2441  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip642">
    <rect x="209" y="47" width="1105" height="711"/>
  </clipPath>
</defs>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="209.079,757.381 1312.76,757.381 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="285.626,757.381 285.626,776.279 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="483.664,757.381 483.664,776.279 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="681.702,757.381 681.702,776.279 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="879.74,757.381 879.74,776.279 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1077.78,757.381 1077.78,776.279 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1275.82,757.381 1275.82,776.279 "/>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 285.626, 806.258)" x="285.626" y="806.258">0</text>
</g>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 483.664, 806.258)" x="483.664" y="806.258">5</text>
</g>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 681.702, 806.258)" x="681.702" y="806.258">10</text>
</g>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 879.74, 806.258)" x="879.74" y="806.258">15</text>
</g>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 1077.78, 806.258)" x="1077.78" y="806.258">20</text>
</g>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 1275.82, 806.258)" x="1275.82" y="806.258">25</text>
</g>
<path clip-path="url(#clip640)" d="M777.532 838.272 L764.641 855.618 L778.2 873.92 L771.293 873.92 L760.917 859.915 L750.541 873.92 L743.634 873.92 L757.48 855.268 L744.812 838.272 L751.719 838.272 L761.172 850.971 L770.625 838.272 L777.532 838.272 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="209.079,757.381 209.079,47.2441 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="209.079,757.381 190.181,757.381 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="209.079,547.292 190.181,547.292 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="209.079,337.202 190.181,337.202 "/>
<polyline clip-path="url(#clip640)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="209.079,127.113 190.181,127.113 "/>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 144.219, 770.381)" x="144.219" y="770.381">0.00</text>
</g>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 144.219, 560.292)" x="144.219" y="560.292">0.05</text>
</g>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 144.219, 350.202)" x="144.219" y="350.202">0.10</text>
</g>
<g clip-path="url(#clip640)">
<text style="fill:#000000; fill-opacity:1; font-family:Times New Roman,TimesNewRoman,Times,Baskerville,Georgia,serif; font-size:39px; text-anchor:middle;" transform="rotate(0, 144.219, 140.113)" x="144.219" y="140.113">0.15</text>
</g>
<path clip-path="url(#clip640)" d="M80.1558 566.389 L99.0619 566.389 L99.0619 572.277 L49.855 572.277 L49.855 566.389 L55.2659 566.389 Q52.083 564.543 50.5553 561.742 Q48.9957 558.909 48.9957 554.994 Q48.9957 548.501 54.1519 544.459 Q59.3081 540.385 67.7108 540.385 Q76.1136 540.385 81.2698 544.459 Q86.426 548.501 86.426 554.994 Q86.426 558.909 84.8982 561.742 Q83.3386 564.543 80.1558 566.389 M67.7108 546.464 Q61.2496 546.464 57.5894 549.138 Q53.8972 551.779 53.8972 556.426 Q53.8972 561.073 57.5894 563.747 Q61.2496 566.389 67.7108 566.389 Q74.172 566.389 77.8641 563.747 Q81.5244 561.073 81.5244 556.426 Q81.5244 551.779 77.8641 549.138 Q74.172 546.464 67.7108 546.464 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M55.3295 510.02 Q54.7566 511.007 54.502 512.185 Q54.2155 513.33 54.2155 514.731 Q54.2155 519.696 57.462 522.37 Q60.6767 525.012 66.7241 525.012 L85.503 525.012 L85.503 530.9 L49.855 530.9 L49.855 525.012 L55.3932 525.012 Q52.1467 523.165 50.5871 520.205 Q48.9957 517.245 48.9957 513.012 Q48.9957 512.407 49.0911 511.675 Q49.1548 510.943 49.3139 510.052 L55.3295 510.02 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M53.9609 491.496 Q53.9609 496.207 57.653 498.944 Q61.3133 501.681 67.7108 501.681 Q74.1084 501.681 77.8005 498.976 Q81.4608 496.239 81.4608 491.496 Q81.4608 486.817 77.7686 484.08 Q74.0765 481.343 67.7108 481.343 Q61.377 481.343 57.6848 484.08 Q53.9609 486.817 53.9609 491.496 M48.9957 491.496 Q48.9957 483.857 53.9609 479.497 Q58.9262 475.136 67.7108 475.136 Q76.4637 475.136 81.4608 479.497 Q86.426 483.857 86.426 491.496 Q86.426 499.167 81.4608 503.527 Q76.4637 507.856 67.7108 507.856 Q58.9262 507.856 53.9609 503.527 Q48.9957 499.167 48.9957 491.496 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M67.7108 439.838 Q61.2496 439.838 57.5894 442.512 Q53.8972 445.154 53.8972 449.801 Q53.8972 454.448 57.5894 457.121 Q61.2496 459.763 67.7108 459.763 Q74.172 459.763 77.8641 457.121 Q81.5244 454.448 81.5244 449.801 Q81.5244 445.154 77.8641 442.512 Q74.172 439.838 67.7108 439.838 M55.2659 459.763 Q52.083 457.917 50.5553 455.116 Q48.9957 452.283 48.9957 448.368 Q48.9957 441.875 54.1519 437.833 Q59.3081 433.759 67.7108 433.759 Q76.1136 433.759 81.2698 437.833 Q86.426 441.875 86.426 448.368 Q86.426 452.283 84.8982 455.116 Q83.3386 457.917 80.1558 459.763 L85.503 459.763 L85.503 465.651 L35.9778 465.651 L35.9778 459.763 L55.2659 459.763 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M67.5835 407.851 Q67.5835 414.948 69.2068 417.686 Q70.83 420.423 74.7449 420.423 Q77.8641 420.423 79.7102 418.386 Q81.5244 416.317 81.5244 412.784 Q81.5244 407.914 78.0869 404.986 Q74.6176 402.026 68.8885 402.026 L67.5835 402.026 L67.5835 407.851 M65.1645 396.17 L85.503 396.17 L85.503 402.026 L80.0921 402.026 Q83.3386 404.031 84.8982 407.023 Q86.426 410.015 86.426 414.344 Q86.426 419.818 83.3705 423.065 Q80.2831 426.279 75.1269 426.279 Q69.1113 426.279 66.0557 422.269 Q63.0002 418.227 63.0002 410.238 L63.0002 402.026 L62.4273 402.026 Q58.3851 402.026 56.1889 404.7 Q53.9609 407.341 53.9609 412.148 Q53.9609 415.203 54.693 418.099 Q55.425 420.996 56.8891 423.669 L51.4783 423.669 Q50.237 420.455 49.6322 417.431 Q48.9957 414.407 48.9957 411.543 Q48.9957 403.808 53.006 399.989 Q57.0164 396.17 65.1645 396.17 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M67.7108 358.516 Q61.2496 358.516 57.5894 361.19 Q53.8972 363.832 53.8972 368.479 Q53.8972 373.126 57.5894 375.799 Q61.2496 378.441 67.7108 378.441 Q74.172 378.441 77.8641 375.799 Q81.5244 373.126 81.5244 368.479 Q81.5244 363.832 77.8641 361.19 Q74.172 358.516 67.7108 358.516 M55.2659 378.441 Q52.083 376.595 50.5553 373.794 Q48.9957 370.961 48.9957 367.046 Q48.9957 360.553 54.1519 356.511 Q59.3081 352.437 67.7108 352.437 Q76.1136 352.437 81.2698 356.511 Q86.426 360.553 86.426 367.046 Q86.426 370.961 84.8982 373.794 Q83.3386 376.595 80.1558 378.441 L85.503 378.441 L85.503 384.329 L35.9778 384.329 L35.9778 378.441 L55.2659 378.441 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M49.855 342.729 L49.855 336.873 L85.503 336.873 L85.503 342.729 L49.855 342.729 M35.9778 342.729 L35.9778 336.873 L43.3938 336.873 L43.3938 342.729 L35.9778 342.729 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M35.9778 324.619 L35.9778 318.763 L85.503 318.763 L85.503 324.619 L35.9778 324.619 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M49.855 306.509 L49.855 300.652 L85.503 300.652 L85.503 306.509 L49.855 306.509 M35.9778 306.509 L35.9778 300.652 L43.3938 300.652 L43.3938 306.509 L35.9778 306.509 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M39.7336 282.605 L49.855 282.605 L49.855 270.542 L54.4065 270.542 L54.4065 282.605 L73.7583 282.605 Q78.1188 282.605 79.3601 281.428 Q80.6014 280.218 80.6014 276.558 L80.6014 270.542 L85.503 270.542 L85.503 276.558 Q85.503 283.337 82.9885 285.916 Q80.4422 288.494 73.7583 288.494 L54.4065 288.494 L54.4065 292.791 L49.855 292.791 L49.855 288.494 L39.7336 288.494 L39.7336 282.605 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip640)" d="M88.8131 248.008 Q95.1789 250.49 97.1204 252.846 Q99.0619 255.201 99.0619 259.148 L99.0619 263.827 L94.1603 263.827 L94.1603 260.389 Q94.1603 257.97 93.0145 256.633 Q91.8687 255.297 87.6037 253.673 L84.9301 252.623 L49.855 267.041 L49.855 260.835 L77.7368 249.695 L49.855 238.555 L49.855 232.348 L88.8131 248.008 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip642)" d="M269.783 757.381 L269.783 757.381 L301.469 757.381 L301.469 757.381 L269.783 757.381 L269.783 757.381  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="269.783,757.381 269.783,757.381 301.469,757.381 301.469,757.381 269.783,757.381 "/>
<path clip-path="url(#clip642)" d="M309.39 757.381 L309.39 757.381 L341.077 757.381 L341.077 757.381 L309.39 757.381 L309.39 757.381  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="309.39,757.381 309.39,757.381 341.077,757.381 341.077,757.381 309.39,757.381 "/>
<path clip-path="url(#clip642)" d="M348.998 757.381 L348.998 757.381 L380.684 757.381 L380.684 757.381 L348.998 757.381 L348.998 757.381  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="348.998,757.381 348.998,757.381 380.684,757.381 380.684,757.381 348.998,757.381 "/>
<path clip-path="url(#clip642)" d="M388.606 757.381 L388.606 757.381 L420.292 757.381 L420.292 757.381 L388.606 757.381 L388.606 757.381  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="388.606,757.381 388.606,757.381 420.292,757.381 420.292,757.381 388.606,757.381 "/>
<path clip-path="url(#clip642)" d="M428.213 757.38 L428.213 757.381 L459.899 757.381 L459.899 757.38 L428.213 757.38 L428.213 757.38  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="428.213,757.38 428.213,757.381 459.899,757.381 459.899,757.38 428.213,757.38 "/>
<path clip-path="url(#clip642)" d="M467.821 757.371 L467.821 757.381 L499.507 757.381 L499.507 757.371 L467.821 757.371 L467.821 757.371  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="467.821,757.371 467.821,757.381 499.507,757.381 499.507,757.371 467.821,757.371 "/>
<path clip-path="url(#clip642)" d="M507.429 757.312 L507.429 757.381 L539.115 757.381 L539.115 757.312 L507.429 757.312 L507.429 757.312  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="507.429,757.312 507.429,757.381 539.115,757.381 539.115,757.312 507.429,757.312 "/>
<path clip-path="url(#clip642)" d="M547.036 757.003 L547.036 757.381 L578.722 757.381 L578.722 757.003 L547.036 757.003 L547.036 757.003  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="547.036,757.003 547.036,757.381 578.722,757.381 578.722,757.003 547.036,757.003 "/>
<path clip-path="url(#clip642)" d="M586.644 755.673 L586.644 757.381 L618.33 757.381 L618.33 755.673 L586.644 755.673 L586.644 755.673  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="586.644,755.673 586.644,757.381 618.33,757.381 618.33,755.673 586.644,755.673 "/>
<path clip-path="url(#clip642)" d="M626.251 750.929 L626.251 757.381 L657.937 757.381 L657.937 750.929 L626.251 750.929 L626.251 750.929  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="626.251,750.929 626.251,757.381 657.937,757.381 657.937,750.929 626.251,750.929 "/>
<path clip-path="url(#clip642)" d="M665.859 736.815 L665.859 757.381 L697.545 757.381 L697.545 736.815 L665.859 736.815 L665.859 736.815  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="665.859,736.815 665.859,757.381 697.545,757.381 697.545,736.815 665.859,736.815 "/>
<path clip-path="url(#clip642)" d="M705.467 701.758 L705.467 757.381 L737.153 757.381 L737.153 701.758 L705.467 701.758 L705.467 701.758  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="705.467,701.758 705.467,757.381 737.153,757.381 737.153,701.758 705.467,701.758 "/>
<path clip-path="url(#clip642)" d="M745.074 629.333 L745.074 757.381 L776.76 757.381 L776.76 629.333 L745.074 629.333 L745.074 629.333  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="745.074,629.333 745.074,757.381 776.76,757.381 776.76,629.333 745.074,629.333 "/>
<path clip-path="url(#clip642)" d="M784.682 506.21 L784.682 757.381 L816.368 757.381 L816.368 506.21 L784.682 506.21 L784.682 506.21  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="784.682,506.21 784.682,757.381 816.368,757.381 816.368,506.21 784.682,506.21 "/>
<path clip-path="url(#clip642)" d="M824.289 338.015 L824.289 757.381 L855.976 757.381 L855.976 338.015 L824.289 338.015 L824.289 338.015  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="824.289,338.015 824.289,757.381 855.976,757.381 855.976,338.015 824.289,338.015 "/>
<path clip-path="url(#clip642)" d="M863.897 163.28 L863.897 757.381 L895.583 757.381 L895.583 163.28 L863.897 163.28 L863.897 163.28  Z" fill="#0000ff" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="863.897,163.28 863.897,757.381 895.583,757.381 895.583,163.28 863.897,163.28 "/>
<path clip-path="url(#clip642)" d="M903.505 47.2441 L903.505 757.381 L935.191 757.381 L935.191 47.2441 L903.505 47.2441 L903.505 47.2441  Z" fill="#0000ff" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="903.505,47.2441 903.505,757.381 935.191,757.381 935.191,47.2441 903.505,47.2441 "/>
<path clip-path="url(#clip642)" d="M943.112 47.2441 L943.112 757.381 L974.798 757.381 L974.798 47.2441 L943.112 47.2441 L943.112 47.2441  Z" fill="#0000ff" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="943.112,47.2441 943.112,757.381 974.798,757.381 974.798,47.2441 943.112,47.2441 "/>
<path clip-path="url(#clip642)" d="M982.72 170.532 L982.72 757.381 L1014.41 757.381 L1014.41 170.532 L982.72 170.532 L982.72 170.532  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="982.72,170.532 982.72,757.381 1014.41,757.381 1014.41,170.532 982.72,170.532 "/>
<path clip-path="url(#clip642)" d="M1022.33 363.574 L1022.33 757.381 L1054.01 757.381 L1054.01 363.574 L1022.33 363.574 L1022.33 363.574  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1022.33,363.574 1022.33,757.381 1054.01,757.381 1054.01,363.574 1022.33,363.574 "/>
<path clip-path="url(#clip642)" d="M1061.94 548.171 L1061.94 757.381 L1093.62 757.381 L1093.62 548.171 L1061.94 548.171 L1061.94 548.171  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1061.94,548.171 1061.94,757.381 1093.62,757.381 1093.62,548.171 1061.94,548.171 "/>
<path clip-path="url(#clip642)" d="M1101.54 672.701 L1101.54 757.381 L1133.23 757.381 L1133.23 672.701 L1101.54 672.701 L1101.54 672.701  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1101.54,672.701 1101.54,757.381 1133.23,757.381 1133.23,672.701 1101.54,672.701 "/>
<path clip-path="url(#clip642)" d="M1141.15 732.843 L1141.15 757.381 L1172.84 757.381 L1172.84 732.843 L1141.15 732.843 L1141.15 732.843  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1141.15,732.843 1141.15,757.381 1172.84,757.381 1172.84,732.843 1141.15,732.843 "/>
<path clip-path="url(#clip642)" d="M1180.76 752.847 L1180.76 757.381 L1212.44 757.381 L1212.44 752.847 L1180.76 752.847 L1180.76 752.847  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1180.76,752.847 1180.76,757.381 1212.44,757.381 1212.44,752.847 1180.76,752.847 "/>
<path clip-path="url(#clip642)" d="M1220.37 756.979 L1220.37 757.381 L1252.05 757.381 L1252.05 756.979 L1220.37 756.979 L1220.37 756.979  Z" fill="#ff0000" fill-rule="evenodd" fill-opacity="0.4"/>
<polyline clip-path="url(#clip642)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1220.37,756.979 1220.37,757.381 1252.05,757.381 1252.05,756.979 1220.37,756.979 "/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="285.626" cy="757.381" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="325.233" cy="757.381" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="364.841" cy="757.381" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="404.449" cy="757.381" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="444.056" cy="757.38" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="483.664" cy="757.371" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="523.272" cy="757.312" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="562.879" cy="757.003" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="602.487" cy="755.673" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="642.094" cy="750.929" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="681.702" cy="736.815" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="721.31" cy="701.758" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="760.917" cy="629.333" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="800.525" cy="506.21" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="840.132" cy="338.015" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#0000ff; stroke:none; fill-opacity:0" cx="879.74" cy="163.28" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#0000ff; stroke:none; fill-opacity:0" cx="919.348" cy="47.2441" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#0000ff; stroke:none; fill-opacity:0" cx="958.955" cy="47.2441" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="998.563" cy="170.532" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="1038.17" cy="363.574" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="1077.78" cy="548.171" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="1117.39" cy="672.701" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="1156.99" cy="732.843" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="1196.6" cy="752.847" r="2"/>
<circle clip-path="url(#clip642)" style="fill:#ff0000; stroke:none; fill-opacity:0" cx="1236.21" cy="756.979" r="2"/>
</svg>





```julia
sum(p_value[1:15]) + sum(p_value[19:25]) # Julia の添字は 1 から始まるので p_value[n+1] が n のときの確率である
```




    0.5205908910845278



`FisherTest()` の場合と異なり，同じ結果を得るためのオプション設定がないので，以下のようなプログラムを使用すればよい。


```julia
using Distributions
function binomial_pvalue(x, n, p=0.5; tail=:both)
    obj = Binomial(n, p)
    tail == :left  && return cdf(obj, x)
    tail == :right && return ccdf(obj, x - 1)
    p == 0 && return Float64(x == 0)
    p == 1 && return Float64(x == n)
    m = n * p
    x == m && return 1
    limit = 1.0000001pdf(obj, x)
    if x < m
        y = sum(pdf.(obj, ceil(Int, m):n) .<= limit)
        cdf(obj, x) + ccdf(obj, n - y)
    else
        y = sum(pdf.(obj, 0:floor(Int, m)) .<= limit)
        cdf(obj, y - 1) + ccdf(obj, x - 1)
    end
end
```




    binomial_pvalue (generic function with 2 methods)




```julia
binomial_pvalue(12, 20)
```




    0.5034446716308596




```julia
binomial_pvalue(4, 20, 0.6, tail=:left)
```




    0.00031703112116863026




```julia
binomial_pvalue(16, 20, 0.6, tail=:right)
```




    0.05095195319416655



- 信頼区間の表示


```julia
result = BinomialTest(5, 26)
confint(result)
```




    (0.06554810873678252, 0.3935055279393218)




```julia
confint(result, level=0.99)
```




    (0.04400829697421974, 0.4550043049581578)




```julia
confint(result, tail=:right)
```




    (0.07898571028519472, 1.0)




```julia
confint(result, tail=:left)
```




    (0.0, 0.36259486197815627)



## $t$ 検定

いわゆる $t$ 検定は，一標本の場合の母平均の検定と独立二標本の平均値の差の検定に大別される。更に，二群の平均値の差の検定は，二群の分散が等しいと仮定する場合と仮定しない場合に分かれる。

なお，対応のある二標本の平均値の差の検定もあるが，これは対応のあるデータの差をとって一標本の場合の母平均の検定をするのと同じである。

これらの検定は `OneSampleTTest()`，`EqualvarianceTTest()`，`UnequalvarianceTTest()` により行う。

### 一標本の検定（母平均の検定）

関数定義<br>
`OneSampleTTest(v::AbstractVector{T<:Real}, μ0::Real = 0)`

対応のある二標本の場合，対応のあるデータの差をとって一標本の検定を行うのと同じである。

■ 使用例


```julia
x = [5.6, 8.1, 6.6, 4.7, 4.8, 9.6, 5.6, 1.3, 4.1, 5.4];
y = [2.0, 3.4, 5.2, 8.0, 9.0, 3.6, 2.7, 0.7, 6.7, 5.7];
z = x .- y;
```


```julia
using HypothesisTests
result = OneSampleTTest(x, y)
```




    One sample t-test
    -----------------
    Population details:
        parameter of interest:   Mean
        value under h_0:         0
        point estimate:          0.88
        95% confidence interval: (-1.614, 3.374)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.4454
    
    Details:
        number of observations:   10
        t-statistic:              0.7981113921334072
        degrees of freedom:       9
        empirical standard error: 1.1026029808291529





```julia
result = OneSampleTTest(z)
```




    One sample t-test
    -----------------
    Population details:
        parameter of interest:   Mean
        value under h_0:         0
        point estimate:          0.88
        95% confidence interval: (-1.614, 3.374)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.4454
    
    Details:
        number of observations:   10
        t-statistic:              0.7981113921334072
        degrees of freedom:       9
        empirical standard error: 1.1026029808291529




■ 個別に表示できる統計量

- $p$ 値


```julia
pvalue(result)
```




    0.4453534218554348




```julia
pvalue(result, tail=:both)
```




    0.4453534218554348




```julia
pvalue(result, tail=:left)
```




    0.7773232890722825




```julia
pvalue(result, tail=:right)
```




    0.2226767109277174



- 信頼区間　信頼区間は母平均の信頼区間である。


```julia
confint(result)
```




    (-1.6142612308053204, 3.3742612308053195)




```julia
confint(result, tail=:both)
```




    (-1.6142612308053204, 3.3742612308053195)




```julia
confint(result, level=0.99)
```




    (-2.7032783553640023, 4.463278355364001)




```julia
confint(result, tail=:right)
```




    (-1.141195783743237, Inf)




```julia
confint(result, tail=:right, level=0.99)
```




    (-2.2309258663578753, Inf)




```julia
confint(result, tail=:left)
```




    (-Inf, 2.901195783743236)



- `n`　サンプルサイズ


```julia
result.n
```




    10




```julia
result.xbar
```




    0.8799999999999997



- `t`　検定統計量（$t$ 分布にしたがう）


```julia
result.t
```




    0.7981113921334072



- df　$t$ 分布の自由度


```julia
result.df
```




    9



- xbar　標本平均<br>
`xbar = mean(x) - mean(y) = mean(x - y) = mean(z)`


```julia
result.xbar
```




    0.8799999999999997



- μ0　母平均


```julia
result.μ0
```




    0



- stderr　標準誤差<br>
`result.t = (result.xbar - result.μ0) / result.stderr`


```julia
result.stderr
```




    1.1026029808291529



### 等分散の場合の $t$ 検定

独立 2 標本の分散が等しいことを仮定する平均値の差の検定である。

一般的には，等分散を仮定しない $t$ 検定（Welch の方法）が推奨される。

関数定義<br>
`EqualVarianceTTest(x::AbstractVector{T<:Real}, y::AbstractVector{T<:Real})`

■ 使用例


```julia
x = [1, 2, 3, 6, 3, 1, 2, 1, 1, 1, 3, 4];
y = [2, 1, 2, 3, 4, 2, 1, 2, 3, 5];
```


```julia
result = EqualVarianceTTest(x, y)
```




    Two sample t-test (equal variance)
    ----------------------------------
    Population details:
        parameter of interest:   Mean difference
        value under h_0:         0
        point estimate:          -0.166667
        95% confidence interval: (-1.448, 1.115)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.7889
    
    Details:
        number of observations:   [12,10]
        t-statistic:              -0.271312734545191
        degrees of freedom:       20
        empirical standard error: 0.6142972497994038




■ 個別に表示できる統計量

- `p`　$p$ 値


```julia
pvalue(result) # tail=:both 両側検定がデフォルト
```




    0.788931157688499




```julia
pvalue(result, tail=:left) # 棄却域が左にある片側検定
```




    0.3944655788442495




```julia
pvalue(result, tail=:right) # 棄却域が右にある片側検定
```




    0.6055344211557505



- 信頼区間


```julia
confint(result) #デフォルトで両側に棄却域がある場合の信頼率 95% の信頼区間
```




    (-1.448068275504171, 1.114734942170838)




```julia
confint(result, level=0.99) # 信頼率 99%
```




    (-1.9145510251333067, 1.5812176917999736)




```julia
confint(result, tail=:left, level=0.99) # 片側と信頼率の指定
```




    (-Inf, 1.386262653673622)



- `t`　検定統計量 $t$


```julia
result.t
```




    -0.271312734545191



- `df`　$t$ 分布の自由度


```julia
result.df
```




    20



- `n_x`, `n_y`　各群のサンプルサイズ


```julia
result.n_x, result.n_y
```




    (12, 10)



- `xbar`, `μ0`　平均値の差と母平均<br>
`xbar = mean(x) - mean(y)`


```julia
result.xbar, result.μ0
```




    (-0.16666666666666652, 0)



- stderr　標準偏差<br>
`t = (result.xbar - result.μ0) / result.stderr`


```julia
result.stderr
```




    0.6142972497994038



### 等分散でない場合 Welch の方法

関数定義<br>
`UnequalVarianceTTest(x::AbstractVector{T<:Real}, y::AbstractVector{T<:Real})`

■ 使用例


```julia
x = [1, 2, 3, 6, 3, 1, 2, 1, 1, 1, 3, 4];
y = [2, 1, 2, 3, 4, 2, 1, 2, 3, 5];
```


```julia
result = UnequalVarianceTTest(x, y)
```




    Two sample t-test (unequal variance)
    ------------------------------------
    Population details:
        parameter of interest:   Mean difference
        value under h_0:         0
        point estimate:          -0.166667
        95% confidence interval: (-1.424, 1.09)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.7849
    
    Details:
        number of observations:   [12,10]
        t-statistic:              -0.2765775336645321
        degrees of freedom:       19.99676443938765
        empirical standard error: 0.6026037778933294




■ 個別に表示できる統計量

- `p`　$p$ 値


```julia
pvalue(result) # tail=:both 両側検定がデフォルト
```




    0.784943053185432




```julia
pvalue(result, tail=:left) # 棄却域が左にある片側検定
```




    0.392471526592716




```julia
pvalue(result, tail=:right) # 棄却域が右にある片側検定
```




    0.607528473407284



- 信頼区間


```julia
confint(result) #デフォルトで両側に棄却域がある場合の信頼率 95% の信頼区間
```




    (-1.423689159406056, 1.0903558260727229)




```julia
confint(result, level=0.99) # 信頼率 99%
```




    (-1.8813078766019782, 1.5479745432686451)




```julia
confint(result, tail=:left, level=0.99) # 片側と信頼率の指定
```




    (-Inf, 1.3567230542137687)



- `t`　検定統計量 $t$


```julia
result.t
```




    -0.2765775336645321



- `df`　$t$ 分布の自由度


```julia
result.df
```




    19.99676443938765



- `n_x`, `n_y`　各群のサンプルサイズ


```julia
result.n_x, result.n_y
```




    (12, 10)



- `xbar`, `μ0`　平均値の差と母平均<br>
`xbar = mean(x) - mean(y)`


```julia
result.xbar, result.μ0
```




    (-0.16666666666666652, 0)



- stderr　標準偏差<br>
`t = (result.xbar - result.μ0) / result.stderr`


```julia
result.stderr
```




    0.6026037778933294




```julia
result.t
```




    -0.2765775336645321



## マン・ホイットニーの $U$ 検定

関数定義<br>
`MannWhitneyUTest(x::AbstractVector{<:Real}, y::AbstractVector{<:Real})`<br>

`ExactMannWhitneyUTest(x::AbstractVector{<:Real}, y::AbstractVector{<:Real})`<br>
`ApproximateMannWhitneyUTest(x::AbstractVector{<:Real}, y::AbstractVector{<:Real})`

マン・ホイットニーの $U$ 検定は，ウィルコクソンの順位和検定とも呼ばれる。

順序尺度以上の独立二標本の代表値の差の検定である。

`MannWhitneyUTest()` はラッパーであり，実際に適用される関数は `ExactMannWhitneyUTest()` か `ApproximateMannWhitneyUTest()` である。

以下の 2 つの条件のいずれかを満たす場合には正確な検定 `ExactMannWhitneyUTest()` が適用される。

1. 同順位データ（tie）がなく，プールされたサンプルサイズが 50 以下の場合
2. 同順位があるが，プールされたサンプルサイズが 10 以下の場合

それ以外の場合には漸近近似検定 `ApproximateMannWhitneyUTest()` が適用される。

しかし，`ExactMannWhitneyUTest()` はデータの並べ替えのすべてを評価するので，程々のサンプルサイズの場合でも計算時間がかかりすぎることがある。

そのため，条件を満たすかどうかに限らず `ExactMannWhitneyUTest()` か `ApproximateMannWhitneyUTest()` を直接選択することもできる。

■ 使用例1

以下のデータは，プールされたサンプルサイズが 22 であるが同順位があるので，条件 1 に反する。また，同順位があるがプールされたサンプルサイズが 11 以上なので，条件 2 にも反する。
したがって，何も指示しない場合は `ApproximateMannWhitneyUTest(x, y)` が適用される。


```julia
x = [1, 2, 3, 6, 3, 1, 2, 1, 1, 1, 3, 4];
y = [2, 1, 2, 3, 4, 2, 1, 2, 3, 5];

approx_result = ApproximateMannWhitneyUTest(x, y)
```




    Approximate Mann-Whitney U test
    -------------------------------
    Population details:
        parameter of interest:   Location parameter (pseudomedian)
        value under h_0:         0
        point estimate:          0.0
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.6334
    
    Details:
        number of observations in each group: [12, 10]
        Mann-Whitney-U statistic:             52.5
        rank sums:                            [137.0, 116.0]
        adjustment for ties:                  672.0
        normal approximation (μ, σ):          (-7.5, 14.6784)




この結果は R の wilcox.test() と同じ結果になる。


```julia
using RCall
R"""
x = c(1, 2, 3, 6, 3, 1, 2, 1, 1, 1, 3, 4)
y = c(2, 1, 2, 3, 4, 2, 1, 2, 3, 5)
wilcox.test(x, y)
"""
```

    [33m[1m┌ [22m[39m[33m[1mWarning: [22m[39mRCall.jl: wilcox.test.default(x, y) で警告がありました:
    [33m[1m│ [22m[39m  タイがあるため、正確な p 値を計算することができません
    [33m[1m└ [22m[39m[90m@ RCall ~/.julia/packages/RCall/dDAVd/src/io.jl:172[39m





    RObject{VecSxp}
    
    	Wilcoxon rank sum test with continuity correction
    
    data:  x and y
    W = 52.5, p-value = 0.6334388940675
    alternative hypothesis: true location shift is not equal to 0
    




あえて ExactMannWhitneyUTest() を適用した結果を以下に示す。


```julia
exact_result = ExactMannWhitneyUTest(x, y)
```




    Exact Mann-Whitney U test
    -------------------------
    Population details:
        parameter of interest:   Location parameter (pseudomedian)
        value under h_0:         0
        point estimate:          0.0
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.6305
    
    Details:
        number of observations in each group: [12, 10]
        Mann-Whitney-U statistic:             52.5
        rank sums:                            [137.0, 116.0]
        adjustment for ties:                  672.0




$p$ 値は 0.6305 となり，`ApproximateMannWhitneyUTest()` の場合の 0.6334388940675 とは異った値になった。

しかし，R の `coin` パッケージを使った正確な検定とも違う。


```julia
using RCall
R"""
x = c(1, 2, 3, 6, 3, 1, 2, 1, 1, 1, 3, 4)
y = c(2, 1, 2, 3, 4, 2, 1, 2, 3, 5)
val = c(x, y)
g = factor(rep(c("a", "b"), c(length(x), length(y))))
df = data.frame(val, g)
library(coin)
wilcox_test(val ~ g, data=df, distribution="exact")
"""
```

    [33m[1m┌ [22m[39m[33m[1mWarning: [22m[39mRCall.jl: 要求されたパッケージ survival をロード中です
    [33m[1m└ [22m[39m[90m@ RCall ~/.julia/packages/RCall/dDAVd/src/io.jl:172[39m





    RObject{S4Sxp}
    
    	Exact Wilcoxon-Mann-Whitney Test
    
    data:  val by g (a, b)
    Z = -0.51095591724442, p-value = 0.6326831063673
    alternative hypothesis: true mu is not equal to 0
    




分割表形式のデータを入力して正確な $p$ 値を計算できる[オンラインサイト](http://aoki2.si.gunma-u.ac.jp/exact/utest/getpar.html)で計算しても，coin ライブラリの結果と同じになる。

同順位のない 50 以下のサンプルサイズデータでも確認してみよう。


```julia
x = [1.99, 14.93, 7.51, 11.58, 4.75, 3.86, 2.74, 5.66, 11.32, 4.63, 8.89, 17.99]
y = [3.04, 19.18, 13.72, 19.31, 15.48, 17.92, 16.94, 7.99, 18.75, 5.4]
approx_result = ApproximateMannWhitneyUTest(x, y)
```




    Approximate Mann-Whitney U test
    -------------------------------
    Population details:
        parameter of interest:   Location parameter (pseudomedian)
        value under h_0:         0
        point estimate:          -9.625
    
    Test summary:
        outcome with 95% confidence: reject h_0
        two-sided p-value:           0.0321
    
    Details:
        number of observations in each group: [12, 10]
        Mann-Whitney-U statistic:             27.0
        rank sums:                            [164.0, 89.0]
        adjustment for ties:                  0.0
        normal approximation (μ, σ):          (-33.0, 15.1658)





```julia
exact_result = ExactMannWhitneyUTest(x, y)
```




    Exact Mann-Whitney U test
    -------------------------
    Population details:
        parameter of interest:   Location parameter (pseudomedian)
        value under h_0:         0
        point estimate:          -9.625
    
    Test summary:
        outcome with 95% confidence: reject h_0
        two-sided p-value:           0.0300
    
    Details:
        number of observations in each group: [12, 10]
        Mann-Whitney-U statistic:             27.0
        rank sums:                            [164.0, 89.0]
        adjustment for ties:                  0.0





```julia
pvalue(approx_result) |> println
pvalue(exact_result)  |> println

```

    0.03211417930790749
    0.029960751322980424


同順位がまったくないデータの場合には，R での結果と一致する。


```julia
using RCall
R"""
x = c(1.99, 14.93, 7.51, 11.58, 4.75, 3.86, 2.74, 5.66, 11.32, 4.63, 8.89, 17.99)
y = c(3.04, 19.18, 13.72, 19.31, 15.48, 17.92, 16.94, 7.99, 18.75, 5.4)
val = c(x, y)
g = factor(rep(c("a", "b"), c(length(x), length(y))))
df = data.frame(val, g)
library(coin)
wilcox_test(val ~ g, data=df, distribution="exact")
"""
```




    RObject{S4Sxp}
    
    	Exact Wilcoxon-Mann-Whitney Test
    
    data:  val by g (a, b)
    Z = -2.1759555622061, p-value = 0.02996075132298
    alternative hypothesis: true mu is not equal to 0
    




[外部リンク:Mann-Whitney U test](https://juliastats.org/HypothesisTests.jl/stable/nonparametric/#Mann-Whitney-U-test-1)において，

When there are no tied ranks, the exact p-value is computed using the pwilcox function from the Rmath package.

と述べているが，ここでいっている「exact p-value」は漸近分布ではなく（$U$ 検定統計量の平均値と分散により，標準正規分布から $p$ 値を求めるのではなく），`pwilcox` で計算したといっているだけで，「exact test による $p$ 値ではない」。

また，

In the presence of tied ranks, a p-value is computed by exhaustive enumeration of permutations, which can be very slow for even moderately sized data sets.

といってはいるが，同順位のあるデータの場合はデータの順列についてすべての評価をしているようには見えない。


なお，プールしたサンプルサイズが 10 以下であれば，「1.12. 並べ替え検定（無作為検定）」を用いて，同順位があっても正確な $p$ 値を求めることができる。


```julia
using StatsBase # tiedrank
function ExactU(x, y)
    z = tiedrank(vcat(x, y...))
    length(z) > 10 && throw(ArgumentError("sample size must be less than 11."))
    pvalue(ExactPermutationTest(z[1:length(x)], z[length(x)+1:end], mean))
end

x = [1, 2, 3, 6, 3];
y = [2, 1, 2, 3, 4];
ExactU(x, y) # p value = 0.7142857142857143
```




    0.7142857142857143



## 符号検定

対応のある二標本の母代表値（中央値）に差があるかどうかの検定である。2 変数の組で，いずれが優れているか，劣っているか，あるいは同等であるかしかわからないときに使われる。どの程度優れているかがわかるときには「11.　ウィルコクソンの符号付き順位和検定」を用いる。

関数定義<br>
`SignTest(x::AbstractVector{T<:Real}, median::Real = 0)`<br>
`SignTest(x::AbstractVector{T<:Real}, y::AbstractVector{T<:Real}, median::Real = 0)`

`SignTest(x, y, median=0)`<br>
`SignTest(z, median=0)`<br>
`x`, `y` は対応のあるデータベクトル。`z` は `x .- y` を事前に計算した場合。`median` は帰無仮説下の中央値。

■ 使用例


```julia
using HypothesisTests

x = [3, 1, 5, 4, 2, 2, 4, 1, 5, 4]
y = [1, 1, 3, 2, 4, 1, 3, 2, 4, 2]
result = SignTest(x, y)
```




    Sign Test
    ---------
    Population details:
        parameter of interest:   Median
        value under h_0:         0.0
        point estimate:          1.0
        95% confidence interval: (0.0, 2.0)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.1797
    
    Details:
        number of observations:       9
        observations larger than 0.0: 7





```julia
result2 = SignTest([1, 0, 1, 1, -1, 1, 1, -1, 1, 1])
```




    Sign Test
    ---------
    Population details:
        parameter of interest:   Median
        value under h_0:         0.0
        point estimate:          1.0
        95% confidence interval: (0.0, 1.0)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.1797
    
    Details:
        number of observations:       9
        observations larger than 0.0: 7




対応する観察値が同じではならないデータ対の数を `n`，`median` より大きいものの対の数を `x` としたときの `BinomialTest(x, n)` と同じである（$p$ 値が同じになる）。


```julia
using HypothesisTests
result3 = BinomialTest(7, 9)
```




    Binomial test
    -------------
    Population details:
        parameter of interest:   Probability of success
        value under h_0:         0.5
        point estimate:          0.777778
        95% confidence interval: (0.3999, 0.9719)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.1797
    
    Details:
        number of observations: 9
        number of successes:    7





```julia
pvalue(result)  |> println
pvalue(result2) |> println
pvalue(result3) |> println
```

    0.17968750000000006
    0.17968750000000006
    0.17968750000000006


■ 個別に表示できる統計量

- `p`　$p$ 値


```julia
pvalue(result) # デフォルトで両側検定
```




    0.17968750000000006




```julia
pvalue(result, tail=:left) # 棄却域が左にある場合の片側検定
```




    0.98046875




```julia
pvalue(result, tail=:right) # 棄却域が右にある場合の片側検定
```




    0.08984375000000003



- confint　信頼区間


```julia
confint(result) # デフォルトで両側に棄却域がある場合で，信頼率が 95% の信頼区間
```




    (0, 2)




```julia
confint(result, level=0.99) # 信頼率の指定
```




    (-1, 2)




```julia
confint(result, tail=:left, level=0.99) # 棄却域が左にある場合の信頼区間
```




    (-1, 0.0)




```julia
confint(result, tail=:right, level=0.99) # 棄却域が右にある場合の信頼区間
```




    (0.0, 2)



## ウィルコクソンの符号付き順位和検定

対応のある二標本の母代表値（中央値）に差があるかどうかの検定である。2 変数の組で，どちらがどの程度優れているかがわかるときにはウィルコクソンの符号付き順位和検定を用いる。

関数定義<br>
`SignedRankTest(x::AbstractVector{<:Real})`<br>
`SignedRankTest(x::AbstractVector{<:Real}, y::AbstractVector{<:Real})`<br>

`ExactSignedRankTest(x::AbstractVector{<:Real}[, y::AbstractVector{<:Real}])`<br>
`ApproximateSignedRankTest(x::AbstractVector{<:Real}[, y::AbstractVector{<:Real}])`

`SignedRankTest(z)`<br>
`SignedRankTest(x，y)`<br>
`x`, `y` は対応のあるデータベクトル。`z` は `x .- y` を事前に計算した場合。

`SignedRankTest()` はラッパーであり，実際に適用される関数は `ExactSignedRankTest()` か `ApproximateSignedRankTest()` である。

以下の 2 つの条件を満たすときには，`ExactSignedRankTest()` が実行される。

1. 同順位がなくて，サンプルサイズが 50 以下である。
2. 同順位があるが，サンプルサイズが 15 以下である。

どちらの条件も満たさないときは，`ApproximateSignedRankTest()` が実行される。

条件を満たすかどうかに限らず，`ApproximateSignedRankTest()` か `ExactSignedRankTest()` を直接選択できる。

■ 使用例


```julia
using HypothesisTests

x = [3, 1, 5, 4, 2, 2, 4, 1, 5, 4]
y = [1, 1, 3, 2, 4, 1, 3, 2, 4, 2]
result = SignedRankTest(x, y)
```




    Exact Wilcoxon signed rank test
    -------------------------------
    Population details:
        parameter of interest:   Location parameter (pseudomedian)
        value under h_0:         0
        point estimate:          1.0
        95% confidence interval: (0.0, 2.0)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.1562
    
    Details:
        number of observations:      10
        Wilcoxon rank-sum statistic: 35.5
        rank sums:                   [35.5, 9.5]
        adjustment for ties:         180.0





```julia
z = x .- y
result2 = SignedRankTest(z)
```




    Exact Wilcoxon signed rank test
    -------------------------------
    Population details:
        parameter of interest:   Location parameter (pseudomedian)
        value under h_0:         0
        point estimate:          1.0
        95% confidence interval: (0.0, 2.0)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.1562
    
    Details:
        number of observations:      10
        Wilcoxon rank-sum statistic: 35.5
        rank sums:                   [35.5, 9.5]
        adjustment for ties:         180.0




■ 個別に表示できる統計量

- p　$p$ 値


```julia
pvalue(result)
```




    0.15625




```julia
pvalue(result, tail=:left)
```




    0.9609375




```julia
pvalue(result, tail=:right)
```




    0.078125



- `confint`　信頼区間


```julia
confint(result)
```




    (0.0, 2.0)




```julia
confint(result, level=0.99)
```




    (-1.0, 2.0)




```julia
confint(result, tail=:left, level=0.99)
```




    (-0.5, Inf)




```julia
confint(result, tail=:right, level=0.99)
```




    (-Inf, 2.0)



- `W`　検定統計量

result3.W

■ 漸近近似検定の場合


```julia
using Random; Random.seed!(123)
x = randn(100)
y = randn(100) .+ 0.1
result3 = ApproximateSignedRankTest(x, y)
```




    Approximate Wilcoxon signed rank test
    -------------------------------------
    Population details:
        parameter of interest:   Location parameter (pseudomedian)
        value under h_0:         0
        point estimate:          0.0187289
        95% confidence interval: (-0.3522, 0.1781)
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.5763
    
    Details:
        number of observations:      100
        Wilcoxon rank-sum statistic: 2362.0
        rank sums:                   [2362.0, 2688.0]
        adjustment for ties:         0.0
        normal approximation (μ, σ): (-163.0, 290.839)




- `mu`, `sigma`　`ApproximateSignedRankTest()` の場合のみ


```julia
result3.mu, result3.sigma
```




    (-163.0, 290.8393027085576)




```julia
using Distributions
z = result3.mu / result3.sigma
```




    -0.5604469495078456




```julia
2*cdf(Normal(), z)
```




    0.5751746153622865




```julia
pvalue(result3) # 一致しない？
```




    0.576347512365529



## 相関係数の検定

ここでは母相関係数が 0 である（無相関）かどうかの検定を取り上げる。HypothesTests にはないが，簡単な関数を作っておこう。

関数定義　2 変数をベクトル x, y で与える場合<br>
`CorTest(x::AbstractVector{<:Real}, y::AbstractVector{<:Real}; level=0.95, method="pearson")`<br>

関数定義　サンプルサイズ n と 相関係数 r で与える場合
`CorTest(n::Int, r::Float64; level=0.95, method="pearson")`

method には以下のものが指定できる。

`method`     | 相関係数
:-------     | :-----
`"pearson"`  | ピアソンの積率相関係数
`"spearman"` | スピアマンの順位相関係数
`"kendall"`  | ケンドールの順位相関係数

スピアマンの順位相関係数，ケンドールの順位相関係数においては，同順位がある場合には近似検定になる。

ケンドールの順位相関係数においては，信頼区間は求めない。


```julia
using Statistics, StatsBase, Distributions
roundn(x, digits) = round(x, digits=digits)
formatp(p) = p < 0.00001 ? "< 0.00001" : "= " * string(roundn(p, 5))
index(method) = indexin(method[1], ['p', 's', 'k'])[1]
function CorTest(x::AbstractVector{<:Real}, y::AbstractVector{<:Real}; level=0.95, method="pearson")
    func = [cor, corspearman, corkendall][index(method)]
    CorTest(length(x), func(x, y); level, method)
end
function CorTest(n::Int, r::Float64; level=0.95, method="pearson")
    if method != "kendall"
        t = r * sqrt((n-2)/(1-r^2))
        df = n-2
        p = 2ccdf(TDist(df), abs(t))
        q = quantile(Normal(), 0.5 - 0.5level)
        conf = tanh.(atanh(r) .+ [q, -q] ./ sqrt(n-3))
        println("n = $n, r = $(roundn(r, 5)), t = $(roundn(t, 5)), df = $df, p-value $(formatp(p))")
        println("$(Int(100level)) percent confidence interval = $(roundn.(conf, 5))")
    else
        z = r / sqrt((4n + 10) / (9n * (n - 1)))
        p = 2ccdf(Normal(), abs(z))
        println("n = $n, r = $(roundn(r, 5)), z = $(roundn(z, 5)), p-value $(formatp(p))")
    end
end;
```

■ 2 変数をベクトルで与える場合


```julia
x = [58.3, 43.6, 49.9, 64.1, 51.6, 36.6, 58.7, 66.7, 50.7, 53.1, 
     56.1, 42.0, 45.5, 30.9, 42.3]
y = [46.3, 51.5, 64.5, 55.6, 63.9, 35.6, 61.2, 56.9, 44.2, 57.3, 
     42.7, 47.1, 32.4, 39.7, 51.0]
CorTest(x, y)
```

    n = 15, r = 0.52225, t = 2.20803, df = 13, p-value = 0.04582
    95 percent confidence interval = [0.01363, 0.81616]



```julia
CorTest(x, y, method="spearman")
```

    n = 15, r = 0.47143, t = 1.92737, df = 13, p-value = 0.07607
    95 percent confidence interval = [-0.05384, 0.79234]



```julia
CorTest(x, y, method="kendall")
```

    n = 15, r = 0.31429, z = 1.63308, p-value = 0.10245



```julia
CorTest(x, y, level=0.99) # 信頼率の設定は，level= で指定する
```

    n = 15, r = 0.52225, t = 2.20803, df = 13, p-value = 0.04582
    99 percent confidence interval = [-0.16269, 0.86753]


■ サンプルサイズと相関係数を与える場合


```julia
CorTest(length(x), cor(x, y))
```

    n = 15, r = 0.52225, t = 2.20803, df = 13, p-value = 0.04582
    95 percent confidence interval = [0.01363, 0.81616]



```julia
CorTest(24, 0.476, level=0.9)
```

    n = 24, r = 0.476, t = 2.53869, df = 22, p-value = 0.01871
    90 percent confidence interval = [0.15754, 0.70478]


## 対応のない $k$ 標本（独立 $k$ 標本）

対応のない $k$ 標本は，対応のない 2 標本の拡張である。

対応のない 2 標本に対する $t$ 検定は，一元配置分散分析に対応する。


### 一元元配置分散分析

HypothesisTests の `OneWayANOVATest()` には，2022/05/21 現在でバグがある。

関数定義<br>
`OneWayANOVATest(groups::AbstractVector{<:Real}...)`

引数として，各標本の観測データベクトルを列挙する。


```julia
using HypothesisTests

g1 = [27.7, 45.2, 32.8, 49.5, 31.0, 55.5, 31.7, 53.9];
g2 = [38.0, 47.4, 55.3, 52.5, 39.2, 34.9];
g3 = [44.0, 29.8, 42.5, 23.4, 20.7, 57.3, 42.0, 56.8, 44.1, 32.7];

result = OneWayANOVATest(g1, g2, g3)
```




    One-way analysis of variance (ANOVA) test
    -----------------------------------------
    Population details:
        parameter of interest:   Means
        value under h_0:         "all equal"
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        p-value:                     0.6612
    
    Details:
        number of observations: [8, 6, 10]
        F statistic:            0.421994
        degrees of freedom:     (2, 21)




正しいプログラム例を挙げておく。


```julia
using Statistics, Distributions

function EqualVarianceOneWayANOVATest(x::AbstractVector{<:Real}...)
    roundn(x, digits) = round(x, digits=digits)
    formatp(p) = p < 0.00001 ? "< 0.00001" : "= " * string(roundn(p, 5))
    X = vcat(x...)
    n, grandmean = length(X), mean(X)
    St = var(X) * (n -1)
    k = length(x)
    ns = zeros(Int, k)
    means = zeros(k)
    for (i, d) in enumerate(x)
        ns[i] = length(d)
        means[i] = mean(d)
    end
    Sb = sum(ni * (meani - grandmean)^2 for (ni, meani) in zip(ns, means))
    Sw = St - Sb
    dfb, dfw = k - 1, n - k
    Vb, Vw = Sb / dfb, Sw / dfw
    F = Vb / Vw
    p = ccdf(FDist(dfb, dfw), F)
    println("F = $(roundn(F, 5)),  df1 = $dfb,  df2 = $dfw,  p-value $(formatp(p))")
end
```




    EqualVarianceOneWayANOVATest (generic function with 1 method)



■ 使用例


```julia
g1 = [27.7, 45.2, 32.8, 49.5, 31.0, 55.5, 31.7, 53.9];
g2 = [38.0, 47.4, 55.3, 52.5, 39.2, 34.9];
g3 = [44.0, 29.8, 42.5, 23.4, 20.7, 57.3, 42.0, 56.8, 44.1, 32.7];

EqualVarianceOneWayANOVATest(g1, g2, g3)
```

    F = 0.40416,  df1 = 2,  df2 = 21,  p-value = 0.67262


### 一元元配置分散分析（ウェルチの方法）

対応のない 2 標本において，等分散を仮定しない平均値の差の検定（ウェルチの方法）の拡張である。

R ではウェルチの方法による一元元配置分散分析がデフォルトなのであるが，Julia にはないので以下の関数を定義しておく。

関数定義<br>
`UnequalVarianceOneWayANOVATestOneWayANOVATest(groups::AbstractVector{<:Real}...)`

`OneWayANOVATest(groups::AbstractVector{<:Real}...)` の場合と同じく，引数として各標本の観測データベクトルを列挙する。


```julia
using Statistics, Distributions

function UnequalVarianceOneWayANOVATest(groups::AbstractVector{<:Real}...)
    roundn(x, digits) = round(x, digits=digits)
    formatp(p) = p < 0.00001 ? "< 0.00001" : "= " * string(roundn(p, 5))
    ni = Int[]
    mi = Float64[]
    vi = Float64[]
    for x in groups
        append!(ni, length(x))
        append!(mi, mean(x))
        append!(vi, var(x))
    end
    k = length(ni)
    wi = ni ./ vi
    sum_wi = sum(wi)
    tmp = sum((1 .- wi ./ sum_wi).^2 ./ (ni .- 1)) ./ (k^2 - 1)
    m = sum(wi .* mi) / sum_wi
    df1, df2 = k - 1, 1 / 3tmp
    F = sum(wi .* (mi .- m).^2) / (df1 * (1 + 2 * (k - 2) * tmp))
    p = ccdf(FDist(df1, df2), F)
    println("F = $(roundn(F, 5)),  df1 = $df1,  df2 = $(roundn(df2, 5)),  p-value $(formatp(p))")
end;
```

■ 使用例


```julia
UnequalVarianceOneWayANOVATest(g1, g2, g3)
```

    F = 0.51339,  df1 = 2,  df2 = 13.589,  p-value = 0.60962


### クラスカル・ウォリス検定

対応のない 2 標本においけるマン・ホイットニーの $U$ 検定の拡張である。

関数定義<br>
`KruskalWallisTest(groups::AbstractVector{<:Real}...)`

引数として各標本の観測データベクトルを列挙する。

■ 使用例


```julia
g1 = [27.7, 45.2, 32.8, 49.5, 31.0, 55.5, 31.7, 53.9];
g2 = [38.0, 47.4, 55.3, 52.5, 39.2, 34.9];
g3 = [44.0, 29.8, 42.5, 23.4, 20.7, 57.3, 42.0, 56.8, 44.1, 32.7];

result = KruskalWallisTest(g1, g2, g3)
```




    Kruskal-Wallis rank sum test (chi-square approximation)
    -------------------------------------------------------
    Population details:
        parameter of interest:   Location parameters
        value under h_0:         "all equal"
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        one-sided p-value:           0.7082
    
    Details:
        number of observation in each group: [8, 6, 10]
        χ²-statistic:                        0.69
        rank sums:                           [98.0, 87.0, 115.0]
        degrees of freedom:                  2
        adjustment for ties:                 1.0




■ 個別に表示できる統計量

- `H`　検定統計量（$\chi^2$ 分布にしたがう）


```julia
result.H
```




    0.6899999999999977



- `df`　$p$ 値を求めるとき，$\chi^2$ 分布で近似するときの自由度


```julia
result.df
```




    2



- `p`　$p$ 値<br>
"one-sided p-value:" と表示されているが，そもそもこの検定は両側/片側の区別はない。単に "p-value:" とすべきである。当然，`tail=:left` も `tail=:right` は言うに及ばず `tail=:both` さえも指定できない。


```julia
pvalue(result)
```




    0.7082203534678008



## コルモゴロフ・スミルノフ検定

1 標本と母分布の差の検定，及び，2 標本の分布の差の検定がある。

### 1 標本の分布の検定

関数定義<br>
`ExactOneSampleKSTest(x::AbstractVector{<:Real}, d::UnivariateDistribution)`<br>
`ApproximateOneSampleKSTest(x::AbstractVector{<:Real}, d::UnivariateDistribution)`

- x は観察ベクトル<br>
- d は 1 変数分布関数<br>
Normal(μ,σ), Uniform(a,b), Weibull(α,θ), Beta(α, β), Cauchy(μ, σ), Exponential(θ), Gamma(α,θ), Gumbel(μ, θ), Logistic(μ,θ), LogNormal(μ,σ) 等がある。　[外部リンク](https://juliastats.org/Distributions.jl/stable/univariate/)

■ 使用例


```julia
using HypothesisTests
using Distributions
using Random; Random.seed!(123)
x = randn(1000);
```

- 正確な検定


```julia
result = ExactOneSampleKSTest(x, Normal()) # 標準正規分布に從うか
```




    Exact one sample Kolmogorov-Smirnov test
    ----------------------------------------
    Population details:
        parameter of interest:   Supremum of CDF differences
        value under h_0:         0.0
        point estimate:          0.0300133
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.3222
    
    Details:
        number of observations:   1000




`pvalue()` により，両側検定の $p$ 値が表示できる。


```julia
pvalue(result) # 両側検定
```




    0.32218030504370365




```julia
pvalue(result, tail=:left) # 左片側検定
```




    0.985395153969924




```julia
pvalue(result, tail=:right) # 右片側検定
```




    0.16177235356103092



- 漸近近似検定


```julia
result2 = ApproximateOneSampleKSTest(randn(100), Normal()) # 一様分布に從うか
```




    Approximate one sample Kolmogorov-Smirnov test
    ----------------------------------------------
    Population details:
        parameter of interest:   Supremum of CDF differences
        value under h_0:         0.0
        point estimate:          0.0944015
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.3349
    
    Details:
        number of observations:   100
        KS-statistic:             0.9440152502489629




pvalue() により，両側検定の  𝑝  値が表示できる。


```julia
pvalue(result2) # 両側検定
```




    0.3348891803417554




```julia
pvalue(result2, tail=:left) # 左片側検定
```




    0.16824574754375227




```julia
pvalue(result2, tail=:right) # 右片側検定
```




    0.980499551913982



### 2 標本の分布の差の検定

2 標本の分布に差があるかどうかの検定である。

関数定義<br>
`ApproximateTwoSampleKSTest(x::AbstractVector{<:Real}, y::AbstractVector{<:Real})`

`ApproximateTwoSampleKSTest()` は以下の戻り値を持つ。

■ 使用例


```julia
using Distributions
using Random; Random.seed!(456)
x = randn(100);         # 標準正規乱数
y = randn(100) .+ 0.15; # 母平均が 0.15
result = ApproximateTwoSampleKSTest(x, y)
```




    Approximate two sample Kolmogorov-Smirnov test
    ----------------------------------------------
    Population details:
        parameter of interest:   Supremum of CDF differences
        value under h_0:         0.0
        point estimate:          0.2
    
    Test summary:
        outcome with 95% confidence: reject h_0
        two-sided p-value:           0.0366
    
    Details:
        number of observations:   [100,100]
        KS-statistic:              1.4142135623730954




■ 個別に表示できる統計量

- `p`　$p$ 値


```julia
pvalue(result)
```




    0.03663105270711932




```julia
pvalue(result, tail=:left)
```




    0.9607894391523232




```julia
pvalue(result, tail=:right)
```




    0.018315638888734147



## アンダーソン・ダーリング検定

1 標本の場合指定した分布に従うかどうかの検定，$k$ 標本の場合はそれらすべてが同じ分布に従うかどうかの検定である。

### 1 標本の場合

関数定義<br>
`OneSampleADTest(x::AbstractVector{<:Real}, d::UnivariateDistribution)`

`x` は観察ベクトル<br>
`d` は 1 変数分布関数<br>
Normal(μ,σ), Uniform(a,b), Weibull(α,θ), Beta(α, β), Cauchy(μ, σ), Exponential(θ), Gamma(α,θ), Gumbel(μ, θ), Logistic(μ,θ), LogNormal(μ,σ) 等がある。　[外部リンク](https://juliastats.org/Distributions.jl/stable/univariate/)

■


```julia
using Distributions
using Random; Random.seed!(123)
x = randn(1000);

result = OneSampleADTest(x, Normal()) # 標準正規分布に從うか
```




    One sample Anderson-Darling test
    --------------------------------
    Population details:
        parameter of interest:   not implemented yet
        value under h_0:         NaN
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        one-sided p-value:           0.2543
    
    Details:
        number of observations:   1000
        sample mean:              -0.05002771798850483
        sample SD:                0.9862398192221139
        A² statistic:             1.2358386455035488




■ 個別に表示できる統計量

- `p`　$p$ 値<br>
"one-sided p-value:" と表示されているが，そもそもこの検定は両側/片側の区別はない。単に "p-value:" とすべきである。当然，`tail=:left` も `tail=:right` は言うに及ばず `tail=:both` さえも指定できない。


```julia
pvalue(result)
```




    0.2542809445499802



- A²　検定統計量


```julia
result.A²
```




    1.2358386455035488



### $k$ 標本の場合

関数定義<br>
`KSampleADTest(xs::AbstractVector{<:Real}...; modified = true, nsim = 0)`

引数は，各標本の測定値ベクトルを列挙する。<br>
$p$ 値の計算を標準正規分布により漸近検定で求めるとき `modified=true` にする。<br>
シミュレーションにより $p$ 値を求めるときは，シミュレーションの回数を `nsim` で指定する。<br>
`nsim=0` のときはシミュレーションを行わず，漸近検定で $p$ 値を求める。

■ 使用例1


```julia
using Distributions
using Random; Random.seed!(456)
x = randn(100);         # 標準正規乱数
y = randn(100) .+ 0.15; # 母平均が 0.15
result = KSampleADTest(x, y)
```




    k-sample Anderson-Darling test
    ------------------------------
    Population details:
        parameter of interest:   not implemented yet
        value under h_0:         NaN
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: reject h_0
        one-sided p-value:           0.0040
    
    Details:
        number of samples:        2
        number of observations:   200
        SD of A²k:                0.7541939849473112
        A²k statistic:            4.655692755994917
        standardized statistic:   4.847151832230945
        modified test:            true
        p-value calculation:      asymptotic




■ 個別に表示できる統計量

- `p`　$p$ 値<br>
"one-sided p-value:" と表示されているが，そもそもこの検定は両側/片側の区別はない。単に "p-value:" とすべきである。当然，`tail=:left` も `tail=:right` は言うに及ばず `tail=:both` さえも指定できない。


```julia
pvalue(result)
```




    0.00403630676510518



- `A²k`　検定統計量


```julia
result.A²k
```




    4.655692755994917



使用例2


```julia
result = KSampleADTest(x, y, modified=false)
```




    k-sample Anderson-Darling test
    ------------------------------
    Population details:
        parameter of interest:   not implemented yet
        value under h_0:         NaN
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: reject h_0
        one-sided p-value:           0.0041
    
    Details:
        number of samples:        2
        number of observations:   200
        SD of A²k:                0.7541939849473112
        A²k statistic:            4.639424885412627
        standardized statistic:   4.825581956433769
        modified test:            false
        p-value calculation:      asymptotic




■ 使用例3


```julia
result = KSampleADTest(x, y, randn(100) .+ 1.0, nsim=10000)
```




    k-sample Anderson-Darling test
    ------------------------------
    Population details:
        parameter of interest:   not implemented yet
        value under h_0:         NaN
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: reject h_0
        one-sided p-value:           <1e-99
    
    Details:
        number of samples:        3
        number of observations:   300
        SD of A²k:                1.0681421196124696
        A²k statistic:            38.555683139480266
        standardized statistic:   34.22361357002096
        modified test:            true
        p-value calculation:      simulation
        number of simulations:    10000




## ワルド・ウォルフォビッツ連検定

関数定義<br>
`WaldWolfowitzTest(x::AbstractVector{Bool})`<br>
`WaldWolfowitzTest(x::AbstractVector{<:Real})`

引数が実数ベクトルの場合は，平均値より大きいか小さいかの論理ベクトルに変換して検定に用いられる。

■ 使用例


```julia
using HypothesisTests
using Distributions
using Random; Random.seed!(456)
x = rand(1:5, 100);
result = WaldWolfowitzTest(x)
```




    Wald-Wolfowitz Test
    -------------------
    Population details:
        parameter of interest:   Number of runs
        value under h_0:         48.58
        point estimate:          53
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        two-sided p-value:           0.3502
    
    Details:
        number of runs:  53
        z-statistic:     0.9341742794043235




■ 個別に表示できる統計量

- `p`　$p$ 値


```julia
pvalue(result)
```




    0.350214000986417




```julia
pvalue(result, tail=:left)
```




    0.8248929995067915




```julia
pvalue(result, tail=:right)
```




    0.1751070004932085



- `nabove`, `nbelow`, `nruns`, `μ`, `σ`, `z`<br>
平均値より大きいデータの個数，平均値より小さいデータの個数，連の個数，標準正規分布で近似するときの連の平均と標準偏差，標準化得点


```julia
result.nabove, result.nbelow, result.nruns, result.μ, result.σ, result.z
```




    (61, 39, 53, 48.58, 4.731451183625411, 0.9341742794043235)




```julia
(result.nruns - result.μ) / result.σ # = result.z
```




    0.9341742794043235




```julia
using Distributions
2ccdf(Normal(), result.z) # = pvalur(result)
```




    0.350214000986417



## 並べ替え検定（無作為検定）

2 標本に対して，指定した関数を使って並べ替え検定（無作為検定）を行う。

関数定義<br>

- 正確検定<br>
`ExactPermutationTest(x::Vector, y::Vector, f::Function)`<br>
$n_x$, $n_y$ をサンプルサイズとしたとき，$(n_x + n_y)!$ 通りのデータの並べ替えに対して $f(x)$, $f(y)$ に差があるか検定する。

- 近似検定<br>
`ApproximatePermutationTest(x::Vector, y::Vector, f::Function, n::Int)`<br>
$(n_x + n_y)!$ 通りのデータの並べ替えのなかから $n$ 通りだけ抽出して $f(x)$, $f(y)$ に差があるか検定する。

■ 使用例1　平均値の差を検定する


```julia
using Statistics
x = [2, 1, 3, 2, 5];
y = [4, 3, 2, 5, 4];
result = ExactPermutationTest(x, y, mean)
```




    Permutation Test
    ----------------
    Population details:
        parameter of interest:   not implemented yet
        value under h_0:         NaN
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        p-value:                     0.3730
    
    Details:
        observation: -1.0
        samples: [-1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0  …  1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]




■ 個別に表示できる統計量

- `p`　$p$ 値


```julia
pvalue(result)
```




    0.373015873015873




```julia
pvalue(result, tail=:left)
```




    0.1865079365079365




```julia
pvalue(result, tail=:right)
```




    0.9126984126984127



- `observation`　観察値


```julia
result.observation
```




    -1.0



- `samples`　シミュレーションの値


```julia
first(result.samples, 5)
```




    5-element Vector{Float64}:
     -1.0
     -1.0
     -1.0
     -1.0
     -1.0



`result.samples` にシミュレーションの値が返されるので，ヒストグラムを描いてみる。


```julia
using Plots
histogram(result.samples)
```




<?xml version="1.0" encoding="utf-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="600" height="400" viewBox="0 0 2400 1600">
<defs>
  <clipPath id="clip730">
    <rect x="0" y="0" width="2400" height="1600"/>
  </clipPath>
</defs>
<path clip-path="url(#clip730)" d="M0 1600 L2400 1600 L2400 8.88178e-14 L0 8.88178e-14  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip731">
    <rect x="480" y="0" width="1681" height="1600"/>
  </clipPath>
</defs>
<path clip-path="url(#clip730)" d="M275.136 1486.45 L2352.76 1486.45 L2352.76 47.2441 L275.136 47.2441  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip732">
    <rect x="275" y="47" width="2079" height="1440"/>
  </clipPath>
</defs>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="431.055,1486.45 431.055,47.2441 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="872.501,1486.45 872.501,47.2441 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="1313.95,1486.45 1313.95,47.2441 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="1755.39,1486.45 1755.39,47.2441 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="2196.84,1486.45 2196.84,47.2441 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,1486.45 2352.76,1486.45 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="431.055,1486.45 431.055,1467.55 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="872.501,1486.45 872.501,1467.55 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1313.95,1486.45 1313.95,1467.55 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1755.39,1486.45 1755.39,1467.55 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2196.84,1486.45 2196.84,1467.55 "/>
<path clip-path="url(#clip730)" d="M400.997 1532.02 L430.673 1532.02 L430.673 1535.95 L400.997 1535.95 L400.997 1532.02 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M444.793 1544.91 L461.113 1544.91 L461.113 1548.85 L439.168 1548.85 L439.168 1544.91 Q441.83 1542.16 446.414 1537.53 Q451.02 1532.88 452.201 1531.53 Q454.446 1529.01 455.326 1527.27 Q456.228 1525.51 456.228 1523.82 Q456.228 1521.07 454.284 1519.33 Q452.363 1517.6 449.261 1517.6 Q447.062 1517.6 444.608 1518.36 Q442.178 1519.13 439.4 1520.68 L439.4 1515.95 Q442.224 1514.82 444.678 1514.24 Q447.131 1513.66 449.168 1513.66 Q454.539 1513.66 457.733 1516.35 Q460.927 1519.03 460.927 1523.52 Q460.927 1525.65 460.117 1527.57 Q459.33 1529.47 457.224 1532.07 Q456.645 1532.74 453.543 1535.95 Q450.441 1539.15 444.793 1544.91 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M842.258 1532.02 L871.933 1532.02 L871.933 1535.95 L842.258 1535.95 L842.258 1532.02 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M882.836 1544.91 L890.475 1544.91 L890.475 1518.55 L882.165 1520.21 L882.165 1515.95 L890.429 1514.29 L895.105 1514.29 L895.105 1544.91 L902.743 1544.91 L902.743 1548.85 L882.836 1548.85 L882.836 1544.91 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M1313.95 1517.37 Q1310.34 1517.37 1308.51 1520.93 Q1306.7 1524.47 1306.7 1531.6 Q1306.7 1538.71 1308.51 1542.27 Q1310.34 1545.82 1313.95 1545.82 Q1317.58 1545.82 1319.39 1542.27 Q1321.21 1538.71 1321.21 1531.6 Q1321.21 1524.47 1319.39 1520.93 Q1317.58 1517.37 1313.95 1517.37 M1313.95 1513.66 Q1319.76 1513.66 1322.81 1518.27 Q1325.89 1522.85 1325.89 1531.6 Q1325.89 1540.33 1322.81 1544.94 Q1319.76 1549.52 1313.95 1549.52 Q1308.14 1549.52 1305.06 1544.94 Q1302 1540.33 1302 1531.6 Q1302 1522.85 1305.06 1518.27 Q1308.14 1513.66 1313.95 1513.66 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M1745.77 1544.91 L1753.41 1544.91 L1753.41 1518.55 L1745.1 1520.21 L1745.1 1515.95 L1753.37 1514.29 L1758.04 1514.29 L1758.04 1544.91 L1765.68 1544.91 L1765.68 1548.85 L1745.77 1548.85 L1745.77 1544.91 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M2191.49 1544.91 L2207.81 1544.91 L2207.81 1548.85 L2185.87 1548.85 L2185.87 1544.91 Q2188.53 1542.16 2193.11 1537.53 Q2197.72 1532.88 2198.9 1531.53 Q2201.14 1529.01 2202.02 1527.27 Q2202.93 1525.51 2202.93 1523.82 Q2202.93 1521.07 2200.98 1519.33 Q2199.06 1517.6 2195.96 1517.6 Q2193.76 1517.6 2191.3 1518.36 Q2188.87 1519.13 2186.1 1520.68 L2186.1 1515.95 Q2188.92 1514.82 2191.37 1514.24 Q2193.83 1513.66 2195.87 1513.66 Q2201.24 1513.66 2204.43 1516.35 Q2207.62 1519.03 2207.62 1523.52 Q2207.62 1525.65 2206.81 1527.57 Q2206.03 1529.47 2203.92 1532.07 Q2203.34 1532.74 2200.24 1535.95 Q2197.14 1539.15 2191.49 1544.91 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="275.136,1445.72 2352.76,1445.72 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="275.136,1231.43 2352.76,1231.43 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="275.136,1017.14 2352.76,1017.14 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="275.136,802.847 2352.76,802.847 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="275.136,588.557 2352.76,588.557 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="275.136,374.267 2352.76,374.267 "/>
<polyline clip-path="url(#clip732)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="275.136,159.978 2352.76,159.978 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,1486.45 275.136,47.2441 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,1445.72 294.034,1445.72 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,1231.43 294.034,1231.43 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,1017.14 294.034,1017.14 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,802.847 294.034,802.847 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,588.557 294.034,588.557 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,374.267 294.034,374.267 "/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="275.136,159.978 294.034,159.978 "/>
<path clip-path="url(#clip730)" d="M227.192 1431.51 Q223.581 1431.51 221.752 1435.08 Q219.947 1438.62 219.947 1445.75 Q219.947 1452.86 221.752 1456.42 Q223.581 1459.96 227.192 1459.96 Q230.826 1459.96 232.632 1456.42 Q234.46 1452.86 234.46 1445.75 Q234.46 1438.62 232.632 1435.08 Q230.826 1431.51 227.192 1431.51 M227.192 1427.81 Q233.002 1427.81 236.058 1432.42 Q239.136 1437 239.136 1445.75 Q239.136 1454.48 236.058 1459.08 Q233.002 1463.67 227.192 1463.67 Q221.382 1463.67 218.303 1459.08 Q215.248 1454.48 215.248 1445.75 Q215.248 1437 218.303 1432.42 Q221.382 1427.81 227.192 1427.81 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M54.5569 1251.22 L62.1958 1251.22 L62.1958 1224.85 L53.8856 1226.52 L53.8856 1222.26 L62.1495 1220.59 L66.8254 1220.59 L66.8254 1251.22 L74.4642 1251.22 L74.4642 1255.15 L54.5569 1255.15 L54.5569 1251.22 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M83.9086 1249.27 L88.7928 1249.27 L88.7928 1255.15 L83.9086 1255.15 L83.9086 1249.27 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M108.978 1223.67 Q105.367 1223.67 103.538 1227.24 Q101.733 1230.78 101.733 1237.91 Q101.733 1245.01 103.538 1248.58 Q105.367 1252.12 108.978 1252.12 Q112.612 1252.12 114.418 1248.58 Q116.246 1245.01 116.246 1237.91 Q116.246 1230.78 114.418 1227.24 Q112.612 1223.67 108.978 1223.67 M108.978 1219.97 Q114.788 1219.97 117.844 1224.58 Q120.922 1229.16 120.922 1237.91 Q120.922 1246.64 117.844 1251.24 Q114.788 1255.82 108.978 1255.82 Q103.168 1255.82 100.089 1251.24 Q97.0335 1246.64 97.0335 1237.91 Q97.0335 1229.16 100.089 1224.58 Q103.168 1219.97 108.978 1219.97 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M157.311 1229.69 L146.732 1240.32 L157.311 1250.89 L154.556 1253.7 L143.931 1243.07 L133.306 1253.7 L130.575 1250.89 L141.131 1240.32 L130.575 1229.69 L133.306 1226.89 L143.931 1237.51 L154.556 1226.89 L157.311 1229.69 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M169.672 1251.22 L177.311 1251.22 L177.311 1224.85 L169.001 1226.52 L169.001 1222.26 L177.265 1220.59 L181.94 1220.59 L181.94 1251.22 L189.579 1251.22 L189.579 1255.15 L169.672 1255.15 L169.672 1251.22 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M209.024 1223.67 Q205.413 1223.67 203.584 1227.24 Q201.778 1230.78 201.778 1237.91 Q201.778 1245.01 203.584 1248.58 Q205.413 1252.12 209.024 1252.12 Q212.658 1252.12 214.463 1248.58 Q216.292 1245.01 216.292 1237.91 Q216.292 1230.78 214.463 1227.24 Q212.658 1223.67 209.024 1223.67 M209.024 1219.97 Q214.834 1219.97 217.889 1224.58 Q220.968 1229.16 220.968 1237.91 Q220.968 1246.64 217.889 1251.24 Q214.834 1255.82 209.024 1255.82 Q203.214 1255.82 200.135 1251.24 Q197.079 1246.64 197.079 1237.91 Q197.079 1229.16 200.135 1224.58 Q203.214 1219.97 209.024 1219.97 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M222.153 1199.66 L237.068 1199.66 L237.068 1202.86 L225.632 1202.86 L225.632 1209.74 Q226.46 1209.46 227.287 1209.33 Q228.115 1209.18 228.943 1209.18 Q233.645 1209.18 236.39 1211.76 Q239.136 1214.33 239.136 1218.73 Q239.136 1223.27 236.315 1225.79 Q233.494 1228.29 228.36 1228.29 Q226.592 1228.29 224.748 1227.99 Q222.924 1227.69 220.968 1227.08 L220.968 1223.27 Q222.661 1224.19 224.466 1224.64 Q226.272 1225.09 228.284 1225.09 Q231.538 1225.09 233.438 1223.38 Q235.337 1221.67 235.337 1218.73 Q235.337 1215.8 233.438 1214.09 Q231.538 1212.38 228.284 1212.38 Q226.761 1212.38 225.237 1212.72 Q223.733 1213.05 222.153 1213.77 L222.153 1199.66 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M57.7745 1036.93 L74.0939 1036.93 L74.0939 1040.86 L52.1495 1040.86 L52.1495 1036.93 Q54.8115 1034.17 59.3949 1029.54 Q64.0013 1024.89 65.1819 1023.55 Q67.4272 1021.03 68.3068 1019.29 Q69.2096 1017.53 69.2096 1015.84 Q69.2096 1013.09 67.2652 1011.35 Q65.3439 1009.61 62.2421 1009.61 Q60.043 1009.61 57.5893 1010.38 Q55.1588 1011.14 52.381 1012.69 L52.381 1007.97 Q55.2051 1006.84 57.6588 1006.26 Q60.1124 1005.68 62.1495 1005.68 Q67.5198 1005.68 70.7142 1008.36 Q73.9087 1011.05 73.9087 1015.54 Q73.9087 1017.67 73.0985 1019.59 Q72.3115 1021.49 70.205 1024.08 Q69.6263 1024.75 66.5245 1027.97 Q63.4226 1031.16 57.7745 1036.93 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M83.9086 1034.98 L88.7928 1034.98 L88.7928 1040.86 L83.9086 1040.86 L83.9086 1034.98 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M108.978 1009.38 Q105.367 1009.38 103.538 1012.95 Q101.733 1016.49 101.733 1023.62 Q101.733 1030.73 103.538 1034.29 Q105.367 1037.83 108.978 1037.83 Q112.612 1037.83 114.418 1034.29 Q116.246 1030.73 116.246 1023.62 Q116.246 1016.49 114.418 1012.95 Q112.612 1009.38 108.978 1009.38 M108.978 1005.68 Q114.788 1005.68 117.844 1010.29 Q120.922 1014.87 120.922 1023.62 Q120.922 1032.35 117.844 1036.95 Q114.788 1041.54 108.978 1041.54 Q103.168 1041.54 100.089 1036.95 Q97.0335 1032.35 97.0335 1023.62 Q97.0335 1014.87 100.089 1010.29 Q103.168 1005.68 108.978 1005.68 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M157.311 1015.4 L146.732 1026.03 L157.311 1036.6 L154.556 1039.41 L143.931 1028.78 L133.306 1039.41 L130.575 1036.6 L141.131 1026.03 L130.575 1015.4 L133.306 1012.6 L143.931 1023.23 L154.556 1012.6 L157.311 1015.4 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M169.672 1036.93 L177.311 1036.93 L177.311 1010.56 L169.001 1012.23 L169.001 1007.97 L177.265 1006.3 L181.94 1006.3 L181.94 1036.93 L189.579 1036.93 L189.579 1040.86 L169.672 1040.86 L169.672 1036.93 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M209.024 1009.38 Q205.413 1009.38 203.584 1012.95 Q201.778 1016.49 201.778 1023.62 Q201.778 1030.73 203.584 1034.29 Q205.413 1037.83 209.024 1037.83 Q212.658 1037.83 214.463 1034.29 Q216.292 1030.73 216.292 1023.62 Q216.292 1016.49 214.463 1012.95 Q212.658 1009.38 209.024 1009.38 M209.024 1005.68 Q214.834 1005.68 217.889 1010.29 Q220.968 1014.87 220.968 1023.62 Q220.968 1032.35 217.889 1036.95 Q214.834 1041.54 209.024 1041.54 Q203.214 1041.54 200.135 1036.95 Q197.079 1032.35 197.079 1023.62 Q197.079 1014.87 200.135 1010.29 Q203.214 1005.68 209.024 1005.68 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M222.153 985.374 L237.068 985.374 L237.068 988.571 L225.632 988.571 L225.632 995.454 Q226.46 995.172 227.287 995.041 Q228.115 994.89 228.943 994.89 Q233.645 994.89 236.39 997.467 Q239.136 1000.04 239.136 1004.44 Q239.136 1008.98 236.315 1011.5 Q233.494 1014 228.36 1014 Q226.592 1014 224.748 1013.7 Q222.924 1013.4 220.968 1012.8 L220.968 1008.98 Q222.661 1009.9 224.466 1010.35 Q226.272 1010.8 228.284 1010.8 Q231.538 1010.8 233.438 1009.09 Q235.337 1007.38 235.337 1004.44 Q235.337 1001.51 233.438 999.799 Q231.538 998.088 228.284 998.088 Q226.761 998.088 225.237 998.426 Q223.733 998.765 222.153 999.479 L222.153 985.374 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M67.9133 807.94 Q71.2698 808.658 73.1448 810.926 Q75.0429 813.195 75.0429 816.528 Q75.0429 821.644 71.5244 824.445 Q68.0059 827.246 61.5245 827.246 Q59.3486 827.246 57.0338 826.806 Q54.7421 826.389 52.2884 825.533 L52.2884 821.019 Q54.2328 822.153 56.5477 822.732 Q58.8625 823.31 61.3856 823.31 Q65.7837 823.31 68.0754 821.574 Q70.3902 819.838 70.3902 816.528 Q70.3902 813.472 68.2374 811.76 Q66.1078 810.023 62.2884 810.023 L58.2606 810.023 L58.2606 806.181 L62.4735 806.181 Q65.9226 806.181 67.7513 804.815 Q69.58 803.426 69.58 800.834 Q69.58 798.172 67.6819 796.76 Q65.8069 795.324 62.2884 795.324 Q60.3671 795.324 58.168 795.741 Q55.969 796.158 53.3301 797.037 L53.3301 792.871 Q55.9921 792.13 58.3069 791.76 Q60.6449 791.389 62.705 791.389 Q68.0291 791.389 71.1309 793.82 Q74.2327 796.227 74.2327 800.348 Q74.2327 803.218 72.5892 805.209 Q70.9457 807.176 67.9133 807.94 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M83.9086 820.695 L88.7928 820.695 L88.7928 826.574 L83.9086 826.574 L83.9086 820.695 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M108.978 795.093 Q105.367 795.093 103.538 798.658 Q101.733 802.199 101.733 809.329 Q101.733 816.435 103.538 820 Q105.367 823.542 108.978 823.542 Q112.612 823.542 114.418 820 Q116.246 816.435 116.246 809.329 Q116.246 802.199 114.418 798.658 Q112.612 795.093 108.978 795.093 M108.978 791.389 Q114.788 791.389 117.844 795.996 Q120.922 800.579 120.922 809.329 Q120.922 818.056 117.844 822.662 Q114.788 827.246 108.978 827.246 Q103.168 827.246 100.089 822.662 Q97.0335 818.056 97.0335 809.329 Q97.0335 800.579 100.089 795.996 Q103.168 791.389 108.978 791.389 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M157.311 801.111 L146.732 811.736 L157.311 822.315 L154.556 825.116 L143.931 814.491 L133.306 825.116 L130.575 822.315 L141.131 811.736 L130.575 801.111 L133.306 798.311 L143.931 808.935 L154.556 798.311 L157.311 801.111 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M169.672 822.639 L177.311 822.639 L177.311 796.273 L169.001 797.94 L169.001 793.681 L177.265 792.014 L181.94 792.014 L181.94 822.639 L189.579 822.639 L189.579 826.574 L169.672 826.574 L169.672 822.639 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M209.024 795.093 Q205.413 795.093 203.584 798.658 Q201.778 802.199 201.778 809.329 Q201.778 816.435 203.584 820 Q205.413 823.542 209.024 823.542 Q212.658 823.542 214.463 820 Q216.292 816.435 216.292 809.329 Q216.292 802.199 214.463 798.658 Q212.658 795.093 209.024 795.093 M209.024 791.389 Q214.834 791.389 217.889 795.996 Q220.968 800.579 220.968 809.329 Q220.968 818.056 217.889 822.662 Q214.834 827.246 209.024 827.246 Q203.214 827.246 200.135 822.662 Q197.079 818.056 197.079 809.329 Q197.079 800.579 200.135 795.996 Q203.214 791.389 209.024 791.389 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M222.153 771.084 L237.068 771.084 L237.068 774.281 L225.632 774.281 L225.632 781.165 Q226.46 780.883 227.287 780.751 Q228.115 780.601 228.943 780.601 Q233.645 780.601 236.39 783.177 Q239.136 785.754 239.136 790.155 Q239.136 794.688 236.315 797.208 Q233.494 799.709 228.36 799.709 Q226.592 799.709 224.748 799.408 Q222.924 799.107 220.968 798.506 L220.968 794.688 Q222.661 795.609 224.466 796.061 Q226.272 796.512 228.284 796.512 Q231.538 796.512 233.438 794.8 Q235.337 793.089 235.337 790.155 Q235.337 787.221 233.438 785.509 Q231.538 783.798 228.284 783.798 Q226.761 783.798 225.237 784.136 Q223.733 784.475 222.153 785.19 L222.153 771.084 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M66.5939 581.799 L54.7884 600.248 L66.5939 600.248 L66.5939 581.799 M65.367 577.725 L71.2466 577.725 L71.2466 600.248 L76.1772 600.248 L76.1772 604.136 L71.2466 604.136 L71.2466 612.285 L66.5939 612.285 L66.5939 604.136 L50.9921 604.136 L50.9921 599.623 L65.367 577.725 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M83.9086 606.405 L88.7928 606.405 L88.7928 612.285 L83.9086 612.285 L83.9086 606.405 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M108.978 580.803 Q105.367 580.803 103.538 584.368 Q101.733 587.91 101.733 595.039 Q101.733 602.146 103.538 605.711 Q105.367 609.252 108.978 609.252 Q112.612 609.252 114.418 605.711 Q116.246 602.146 116.246 595.039 Q116.246 587.91 114.418 584.368 Q112.612 580.803 108.978 580.803 M108.978 577.1 Q114.788 577.1 117.844 581.706 Q120.922 586.289 120.922 595.039 Q120.922 603.766 117.844 608.373 Q114.788 612.956 108.978 612.956 Q103.168 612.956 100.089 608.373 Q97.0335 603.766 97.0335 595.039 Q97.0335 586.289 100.089 581.706 Q103.168 577.1 108.978 577.1 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M157.311 586.822 L146.732 597.447 L157.311 608.025 L154.556 610.826 L143.931 600.201 L133.306 610.826 L130.575 608.025 L141.131 597.447 L130.575 586.822 L133.306 584.021 L143.931 594.646 L154.556 584.021 L157.311 586.822 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M169.672 608.349 L177.311 608.349 L177.311 581.984 L169.001 583.65 L169.001 579.391 L177.265 577.725 L181.94 577.725 L181.94 608.349 L189.579 608.349 L189.579 612.285 L169.672 612.285 L169.672 608.349 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M209.024 580.803 Q205.413 580.803 203.584 584.368 Q201.778 587.91 201.778 595.039 Q201.778 602.146 203.584 605.711 Q205.413 609.252 209.024 609.252 Q212.658 609.252 214.463 605.711 Q216.292 602.146 216.292 595.039 Q216.292 587.91 214.463 584.368 Q212.658 580.803 209.024 580.803 M209.024 577.1 Q214.834 577.1 217.889 581.706 Q220.968 586.289 220.968 595.039 Q220.968 603.766 217.889 608.373 Q214.834 612.956 209.024 612.956 Q203.214 612.956 200.135 608.373 Q197.079 603.766 197.079 595.039 Q197.079 586.289 200.135 581.706 Q203.214 577.1 209.024 577.1 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M222.153 556.794 L237.068 556.794 L237.068 559.991 L225.632 559.991 L225.632 566.875 Q226.46 566.593 227.287 566.461 Q228.115 566.311 228.943 566.311 Q233.645 566.311 236.39 568.888 Q239.136 571.464 239.136 575.865 Q239.136 580.398 236.315 582.918 Q233.494 585.42 228.36 585.42 Q226.592 585.42 224.748 585.119 Q222.924 584.818 220.968 584.216 L220.968 580.398 Q222.661 581.32 224.466 581.771 Q226.272 582.222 228.284 582.222 Q231.538 582.222 233.438 580.511 Q235.337 578.799 235.337 575.865 Q235.337 572.931 233.438 571.22 Q231.538 569.508 228.284 569.508 Q226.761 569.508 225.237 569.847 Q223.733 570.185 222.153 570.9 L222.153 556.794 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M53.793 363.435 L72.1494 363.435 L72.1494 367.37 L58.0754 367.37 L58.0754 375.842 Q59.0939 375.495 60.1124 375.333 Q61.131 375.148 62.1495 375.148 Q67.9365 375.148 71.3161 378.319 Q74.6957 381.49 74.6957 386.907 Q74.6957 392.486 71.2235 395.587 Q67.7513 398.666 61.4319 398.666 Q59.256 398.666 56.9875 398.296 Q54.7421 397.925 52.3347 397.185 L52.3347 392.486 Q54.418 393.62 56.6402 394.175 Q58.8625 394.731 61.3393 394.731 Q65.3439 394.731 67.6819 392.625 Q70.0198 390.518 70.0198 386.907 Q70.0198 383.296 67.6819 381.189 Q65.3439 379.083 61.3393 379.083 Q59.4643 379.083 57.5893 379.5 Q55.7375 379.916 53.793 380.796 L53.793 363.435 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M83.9086 392.115 L88.7928 392.115 L88.7928 397.995 L83.9086 397.995 L83.9086 392.115 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M108.978 366.514 Q105.367 366.514 103.538 370.078 Q101.733 373.62 101.733 380.75 Q101.733 387.856 103.538 391.421 Q105.367 394.962 108.978 394.962 Q112.612 394.962 114.418 391.421 Q116.246 387.856 116.246 380.75 Q116.246 373.62 114.418 370.078 Q112.612 366.514 108.978 366.514 M108.978 362.81 Q114.788 362.81 117.844 367.416 Q120.922 372 120.922 380.75 Q120.922 389.476 117.844 394.083 Q114.788 398.666 108.978 398.666 Q103.168 398.666 100.089 394.083 Q97.0335 389.476 97.0335 380.75 Q97.0335 372 100.089 367.416 Q103.168 362.81 108.978 362.81 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M157.311 372.532 L146.732 383.157 L157.311 393.736 L154.556 396.537 L143.931 385.912 L133.306 396.537 L130.575 393.736 L141.131 383.157 L130.575 372.532 L133.306 369.731 L143.931 380.356 L154.556 369.731 L157.311 372.532 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M169.672 394.06 L177.311 394.06 L177.311 367.694 L169.001 369.361 L169.001 365.102 L177.265 363.435 L181.94 363.435 L181.94 394.06 L189.579 394.06 L189.579 397.995 L169.672 397.995 L169.672 394.06 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M209.024 366.514 Q205.413 366.514 203.584 370.078 Q201.778 373.62 201.778 380.75 Q201.778 387.856 203.584 391.421 Q205.413 394.962 209.024 394.962 Q212.658 394.962 214.463 391.421 Q216.292 387.856 216.292 380.75 Q216.292 373.62 214.463 370.078 Q212.658 366.514 209.024 366.514 M209.024 362.81 Q214.834 362.81 217.889 367.416 Q220.968 372 220.968 380.75 Q220.968 389.476 217.889 394.083 Q214.834 398.666 209.024 398.666 Q203.214 398.666 200.135 394.083 Q197.079 389.476 197.079 380.75 Q197.079 372 200.135 367.416 Q203.214 362.81 209.024 362.81 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M222.153 342.504 L237.068 342.504 L237.068 345.702 L225.632 345.702 L225.632 352.585 Q226.46 352.303 227.287 352.172 Q228.115 352.021 228.943 352.021 Q233.645 352.021 236.39 354.598 Q239.136 357.175 239.136 361.576 Q239.136 366.108 236.315 368.628 Q233.494 371.13 228.36 371.13 Q226.592 371.13 224.748 370.829 Q222.924 370.528 220.968 369.926 L220.968 366.108 Q222.661 367.03 224.466 367.481 Q226.272 367.933 228.284 367.933 Q231.538 367.933 233.438 366.221 Q235.337 364.51 235.337 361.576 Q235.337 358.642 233.438 356.93 Q231.538 355.219 228.284 355.219 Q226.761 355.219 225.237 355.557 Q223.733 355.896 222.153 356.61 L222.153 342.504 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M64.3254 164.562 Q61.1773 164.562 59.3254 166.715 Q57.4967 168.867 57.4967 172.617 Q57.4967 176.344 59.3254 178.52 Q61.1773 180.673 64.3254 180.673 Q67.4735 180.673 69.3022 178.52 Q71.1541 176.344 71.1541 172.617 Q71.1541 168.867 69.3022 166.715 Q67.4735 164.562 64.3254 164.562 M73.6077 149.909 L73.6077 154.168 Q71.8485 153.335 70.0429 152.895 Q68.2606 152.455 66.5013 152.455 Q61.8717 152.455 59.418 155.58 Q56.9875 158.705 56.6402 165.025 Q58.006 163.011 60.0662 161.946 Q62.1263 160.858 64.6032 160.858 Q69.8115 160.858 72.8207 164.029 Q75.8531 167.178 75.8531 172.617 Q75.8531 177.941 72.705 181.159 Q69.5568 184.377 64.3254 184.377 Q58.33 184.377 55.1588 179.793 Q51.9875 175.187 51.9875 166.46 Q51.9875 158.266 55.8764 153.404 Q59.7652 148.52 66.3161 148.52 Q68.0754 148.52 69.8578 148.867 Q71.6633 149.215 73.6077 149.909 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M83.9086 177.826 L88.7928 177.826 L88.7928 183.705 L83.9086 183.705 L83.9086 177.826 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M108.978 152.224 Q105.367 152.224 103.538 155.789 Q101.733 159.33 101.733 166.46 Q101.733 173.566 103.538 177.131 Q105.367 180.673 108.978 180.673 Q112.612 180.673 114.418 177.131 Q116.246 173.566 116.246 166.46 Q116.246 159.33 114.418 155.789 Q112.612 152.224 108.978 152.224 M108.978 148.52 Q114.788 148.52 117.844 153.127 Q120.922 157.71 120.922 166.46 Q120.922 175.187 117.844 179.793 Q114.788 184.377 108.978 184.377 Q103.168 184.377 100.089 179.793 Q97.0335 175.187 97.0335 166.46 Q97.0335 157.71 100.089 153.127 Q103.168 148.52 108.978 148.52 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M157.311 158.242 L146.732 168.867 L157.311 179.446 L154.556 182.247 L143.931 171.622 L133.306 182.247 L130.575 179.446 L141.131 168.867 L130.575 158.242 L133.306 155.441 L143.931 166.066 L154.556 155.441 L157.311 158.242 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M169.672 179.77 L177.311 179.77 L177.311 153.404 L169.001 155.071 L169.001 150.812 L177.265 149.145 L181.94 149.145 L181.94 179.77 L189.579 179.77 L189.579 183.705 L169.672 183.705 L169.672 179.77 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M209.024 152.224 Q205.413 152.224 203.584 155.789 Q201.778 159.33 201.778 166.46 Q201.778 173.566 203.584 177.131 Q205.413 180.673 209.024 180.673 Q212.658 180.673 214.463 177.131 Q216.292 173.566 216.292 166.46 Q216.292 159.33 214.463 155.789 Q212.658 152.224 209.024 152.224 M209.024 148.52 Q214.834 148.52 217.889 153.127 Q220.968 157.71 220.968 166.46 Q220.968 175.187 217.889 179.793 Q214.834 184.377 209.024 184.377 Q203.214 184.377 200.135 179.793 Q197.079 175.187 197.079 166.46 Q197.079 157.71 200.135 153.127 Q203.214 148.52 209.024 148.52 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M222.153 128.215 L237.068 128.215 L237.068 131.412 L225.632 131.412 L225.632 138.296 Q226.46 138.014 227.287 137.882 Q228.115 137.732 228.943 137.732 Q233.645 137.732 236.39 140.308 Q239.136 142.885 239.136 147.286 Q239.136 151.819 236.315 154.339 Q233.494 156.84 228.36 156.84 Q226.592 156.84 224.748 156.539 Q222.924 156.238 220.968 155.637 L220.968 151.819 Q222.661 152.74 224.466 153.192 Q226.272 153.643 228.284 153.643 Q231.538 153.643 233.438 151.931 Q235.337 150.22 235.337 147.286 Q235.337 144.352 233.438 142.64 Q231.538 140.929 228.284 140.929 Q226.761 140.929 225.237 141.267 Q223.733 141.606 222.153 142.321 L222.153 128.215 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><polyline clip-path="url(#clip732)" style="stroke:#009af9; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="333.937,1445.72 333.937,1445.72 342.766,1445.72 342.766,1384 351.595,1384 351.595,1445.72 360.424,1445.72 369.253,1445.72 378.081,1445.72 386.91,1445.72 395.739,1445.72 404.568,1445.72 413.397,1445.72 422.226,1445.72 431.055,1445.72 439.884,1445.72 448.713,1445.72 457.542,1445.72 466.371,1445.72 475.2,1445.72 484.028,1445.72 492.857,1445.72 501.686,1445.72 510.515,1445.72 519.344,1445.72 519.344,1291.43 528.173,1291.43 528.173,1445.72 537.002,1445.72 545.831,1445.72 554.66,1445.72 563.489,1445.72 572.318,1445.72 581.146,1445.72 589.975,1445.72 598.804,1445.72 607.633,1445.72 616.462,1445.72 625.291,1445.72 634.12,1445.72 642.949,1445.72 651.778,1445.72 660.607,1445.72 669.436,1445.72 678.264,1445.72 687.093,1445.72 695.922,1445.72 695.922,982.85 704.751,982.85 704.751,1445.72 713.58,1445.72 722.409,1445.72 731.238,1445.72 740.067,1445.72 748.896,1445.72 757.725,1445.72 766.554,1445.72 775.383,1445.72 784.211,1445.72 793.04,1445.72 801.869,1445.72 810.698,1445.72 819.527,1445.72 828.356,1445.72 837.185,1445.72 846.014,1445.72 854.843,1445.72 863.672,1445.72 872.501,1445.72 872.501,674.273 881.329,674.273 881.329,1445.72 890.158,1445.72 898.987,1445.72 907.816,1445.72 916.645,1445.72 925.474,1445.72 934.303,1445.72 943.132,1445.72 951.961,1445.72 960.79,1445.72 969.619,1445.72 978.447,1445.72 987.276,1445.72 996.105,1445.72 1004.93,1445.72 1013.76,1445.72 1022.59,1445.72 1031.42,1445.72 1040.25,1445.72 1040.25,365.696 1049.08,365.696 1049.08,1445.72 1057.91,1445.72 1066.74,1445.72 1075.57,1445.72 1084.39,1445.72 1093.22,1445.72 1102.05,1445.72 1110.88,1445.72 1119.71,1445.72 1128.54,1445.72 1137.37,1445.72 1146.2,1445.72 1155.03,1445.72 1163.85,1445.72 1172.68,1445.72 1181.51,1445.72 1190.34,1445.72 1199.17,1445.72 1208,1445.72 1216.83,1445.72 1216.83,87.9763 1225.66,87.9763 1225.66,1445.72 1234.49,1445.72 1243.31,1445.72 1252.14,1445.72 1260.97,1445.72 1269.8,1445.72 1278.63,1445.72 1287.46,1445.72 1296.29,1445.72 1305.12,1445.72 1313.95,1445.72 1322.78,1445.72 1331.6,1445.72 1340.43,1445.72 1349.26,1445.72 1358.09,1445.72 1366.92,1445.72 1375.75,1445.72 1384.58,1445.72 1393.41,1445.72 1402.24,1445.72 1402.24,87.9763 1411.06,87.9763 1411.06,1445.72 1419.89,1445.72 1428.72,1445.72 1437.55,1445.72 1446.38,1445.72 1455.21,1445.72 1464.04,1445.72 1472.87,1445.72 1481.7,1445.72 1490.52,1445.72 1499.35,1445.72 1508.18,1445.72 1517.01,1445.72 1525.84,1445.72 1534.67,1445.72 1543.5,1445.72 1552.33,1445.72 1561.16,1445.72 1569.98,1445.72 1578.81,1445.72 1578.81,365.696 1587.64,365.696 1587.64,1445.72 1596.47,1445.72 1605.3,1445.72 1614.13,1445.72 1622.96,1445.72 1631.79,1445.72 1640.62,1445.72 1649.44,1445.72 1658.27,1445.72 1667.1,1445.72 1675.93,1445.72 1684.76,1445.72 1693.59,1445.72 1702.42,1445.72 1711.25,1445.72 1720.08,1445.72 1728.9,1445.72 1737.73,1445.72 1746.56,1445.72 1746.56,674.273 1755.39,674.273 1755.39,1445.72 1764.22,1445.72 1773.05,1445.72 1781.88,1445.72 1790.71,1445.72 1799.54,1445.72 1808.37,1445.72 1817.19,1445.72 1826.02,1445.72 1834.85,1445.72 1843.68,1445.72 1852.51,1445.72 1861.34,1445.72 1870.17,1445.72 1879,1445.72 1887.83,1445.72 1896.65,1445.72 1905.48,1445.72 1914.31,1445.72 1923.14,1445.72 1923.14,982.85 1931.97,982.85 1931.97,1445.72 1940.8,1445.72 1949.63,1445.72 1958.46,1445.72 1967.29,1445.72 1976.11,1445.72 1984.94,1445.72 1993.77,1445.72 2002.6,1445.72 2011.43,1445.72 2020.26,1445.72 2029.09,1445.72 2037.92,1445.72 2046.75,1445.72 2055.57,1445.72 2064.4,1445.72 2073.23,1445.72 2082.06,1445.72 2090.89,1445.72 2099.72,1445.72 2099.72,1291.43 2108.55,1291.43 2108.55,1445.72 2117.38,1445.72 2126.21,1445.72 2135.03,1445.72 2143.86,1445.72 2152.69,1445.72 2161.52,1445.72 2170.35,1445.72 2179.18,1445.72 2188.01,1445.72 2196.84,1445.72 2205.67,1445.72 2214.5,1445.72 2223.32,1445.72 2232.15,1445.72 2240.98,1445.72 2249.81,1445.72 2258.64,1445.72 2267.47,1445.72 2276.3,1445.72 2285.13,1445.72 2285.13,1384 2293.96,1384 2293.96,1445.72 "/>
<path clip-path="url(#clip730)" d="M2023.31 198.898 L2283.5 198.898 L2283.5 95.2176 L2023.31 95.2176  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip730)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2023.31,198.898 2283.5,198.898 2283.5,95.2176 2023.31,95.2176 2023.31,198.898 "/>
<polyline clip-path="url(#clip730)" style="stroke:#009af9; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2046.39,147.058 2184.9,147.058 "/>
<path clip-path="url(#clip730)" d="M2221.83 166.745 Q2220.02 171.375 2218.31 172.787 Q2216.6 174.199 2213.73 174.199 L2210.32 174.199 L2210.32 170.634 L2212.82 170.634 Q2214.58 170.634 2215.56 169.8 Q2216.53 168.967 2217.71 165.865 L2218.47 163.921 L2207.99 138.412 L2212.5 138.412 L2220.6 158.689 L2228.7 138.412 L2233.22 138.412 L2221.83 166.745 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip730)" d="M2240.51 160.402 L2248.15 160.402 L2248.15 134.037 L2239.84 135.703 L2239.84 131.444 L2248.1 129.778 L2252.78 129.778 L2252.78 160.402 L2260.42 160.402 L2260.42 164.338 L2240.51 164.338 L2240.51 160.402 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /></svg>




度数分布を求めてみる。


```julia
using FreqTables
freq = freqtable(result.samples)
```




    12-element Named Vector{Int64}
    Dim1  │ 
    ──────┼───────
    -2.2  │  28800
    -1.8  │  72000
    -1.4  │ 216000
    -1.0  │ 360000
    -0.6  │ 504000
    -0.2  │ 633600
    0.2   │ 633600
    0.6   │ 504000
    1.0   │ 360000
    1.4   │ 216000
    1.8   │  72000
    2.2   │  28800



シミュレーションは `(length(x) + length(y))! = 3628800` 回行われる。


```julia
n = sum(freq)
```




    3628800



観察されたデータでの平均値の差は -1 なので，シミュレーションの結果が -1 以下になる場合の数を求める。


```julia
leftn = sum(freq[names(freq)[1] .<= -1])
```




    676800



`(leftn / n)` が片側検定の $p$ 値


```julia
leftn/n
```




    0.1865079365079365



2 倍すれば両側検定の $p$ 値

■ 使用例2　中央値の差を検定する


```julia
result = ExactPermutationTest(x, y, median)
```




    Permutation Test
    ----------------
    Population details:
        parameter of interest:   not implemented yet
        value under h_0:         NaN
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        p-value:                     0.3333
    
    Details:
        observation: -2.0
        samples: [-2.0, -2.0, -2.0, -2.0, -2.0, -2.0, -2.0, -2.0, -2.0, -2.0  …  2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0]




■ 使用例3　全数探索は無理なので，10000 回のシミュレーションを行う。


```julia
result = ApproximatePermutationTest(x, y, mean, 10000)
```




    Permutation Test
    ----------------
    Population details:
        parameter of interest:   not implemented yet
        value under h_0:         NaN
        point estimate:          NaN
    
    Test summary:
        outcome with 95% confidence: fail to reject h_0
        p-value:                     0.3749
    
    Details:
        observation: -1.0
        samples: [-1.4, -0.6, 0.6, -1.4, -0.2, 0.6, 1.0, 0.6, 0.2, -1.0  …  0.6, -1.0, -1.4, 1.0, 0.2, 1.0, -1.0, -1.4, -0.2, -1.0]





```julia
using Plots
histogram(result.samples)
```




<?xml version="1.0" encoding="utf-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="600" height="400" viewBox="0 0 2400 1600">
<defs>
  <clipPath id="clip820">
    <rect x="0" y="0" width="2400" height="1600"/>
  </clipPath>
</defs>
<path clip-path="url(#clip820)" d="M0 1600 L2400 1600 L2400 8.88178e-14 L0 8.88178e-14  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip821">
    <rect x="480" y="0" width="1681" height="1600"/>
  </clipPath>
</defs>
<path clip-path="url(#clip820)" d="M199.283 1486.45 L2352.76 1486.45 L2352.76 47.2441 L199.283 47.2441  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip822">
    <rect x="199" y="47" width="2154" height="1440"/>
  </clipPath>
</defs>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="402.909,1486.45 402.909,47.2441 "/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="828.817,1486.45 828.817,47.2441 "/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="1254.72,1486.45 1254.72,47.2441 "/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="1680.63,1486.45 1680.63,47.2441 "/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="2106.54,1486.45 2106.54,47.2441 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="199.283,1486.45 2352.76,1486.45 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="402.909,1486.45 402.909,1467.55 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="828.817,1486.45 828.817,1467.55 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1254.72,1486.45 1254.72,1467.55 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1680.63,1486.45 1680.63,1467.55 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2106.54,1486.45 2106.54,1467.55 "/>
<path clip-path="url(#clip820)" d="M372.852 1532.02 L402.528 1532.02 L402.528 1535.95 L372.852 1535.95 L372.852 1532.02 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M416.648 1544.91 L432.967 1544.91 L432.967 1548.85 L411.023 1548.85 L411.023 1544.91 Q413.685 1542.16 418.268 1537.53 Q422.875 1532.88 424.055 1531.53 Q426.301 1529.01 427.18 1527.27 Q428.083 1525.51 428.083 1523.82 Q428.083 1521.07 426.139 1519.33 Q424.217 1517.6 421.115 1517.6 Q418.916 1517.6 416.463 1518.36 Q414.032 1519.13 411.254 1520.68 L411.254 1515.95 Q414.078 1514.82 416.532 1514.24 Q418.986 1513.66 421.023 1513.66 Q426.393 1513.66 429.588 1516.35 Q432.782 1519.03 432.782 1523.52 Q432.782 1525.65 431.972 1527.57 Q431.185 1529.47 429.078 1532.07 Q428.5 1532.74 425.398 1535.95 Q422.296 1539.15 416.648 1544.91 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M798.574 1532.02 L828.25 1532.02 L828.25 1535.95 L798.574 1535.95 L798.574 1532.02 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M839.152 1544.91 L846.791 1544.91 L846.791 1518.55 L838.481 1520.21 L838.481 1515.95 L846.745 1514.29 L851.421 1514.29 L851.421 1544.91 L859.06 1544.91 L859.06 1548.85 L839.152 1548.85 L839.152 1544.91 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M1254.72 1517.37 Q1251.11 1517.37 1249.28 1520.93 Q1247.48 1524.47 1247.48 1531.6 Q1247.48 1538.71 1249.28 1542.27 Q1251.11 1545.82 1254.72 1545.82 Q1258.36 1545.82 1260.16 1542.27 Q1261.99 1538.71 1261.99 1531.6 Q1261.99 1524.47 1260.16 1520.93 Q1258.36 1517.37 1254.72 1517.37 M1254.72 1513.66 Q1260.53 1513.66 1263.59 1518.27 Q1266.67 1522.85 1266.67 1531.6 Q1266.67 1540.33 1263.59 1544.94 Q1260.53 1549.52 1254.72 1549.52 Q1248.91 1549.52 1245.84 1544.94 Q1242.78 1540.33 1242.78 1531.6 Q1242.78 1522.85 1245.84 1518.27 Q1248.91 1513.66 1254.72 1513.66 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M1671.01 1544.91 L1678.65 1544.91 L1678.65 1518.55 L1670.34 1520.21 L1670.34 1515.95 L1678.61 1514.29 L1683.28 1514.29 L1683.28 1544.91 L1690.92 1544.91 L1690.92 1548.85 L1671.01 1548.85 L1671.01 1544.91 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M2101.19 1544.91 L2117.51 1544.91 L2117.51 1548.85 L2095.57 1548.85 L2095.57 1544.91 Q2098.23 1542.16 2102.81 1537.53 Q2107.42 1532.88 2108.6 1531.53 Q2110.84 1529.01 2111.72 1527.27 Q2112.63 1525.51 2112.63 1523.82 Q2112.63 1521.07 2110.68 1519.33 Q2108.76 1517.6 2105.66 1517.6 Q2103.46 1517.6 2101.01 1518.36 Q2098.58 1519.13 2095.8 1520.68 L2095.8 1515.95 Q2098.62 1514.82 2101.08 1514.24 Q2103.53 1513.66 2105.57 1513.66 Q2110.94 1513.66 2114.13 1516.35 Q2117.33 1519.03 2117.33 1523.52 Q2117.33 1525.65 2116.52 1527.57 Q2115.73 1529.47 2113.62 1532.07 Q2113.04 1532.74 2109.94 1535.95 Q2106.84 1539.15 2101.19 1544.91 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="199.283,1486.45 2352.76,1486.45 "/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="199.283,1079.66 2352.76,1079.66 "/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="199.283,672.879 2352.76,672.879 "/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="199.283,266.094 2352.76,266.094 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="199.283,1486.45 199.283,47.2441 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="199.283,1486.45 218.181,1486.45 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="199.283,1079.66 218.181,1079.66 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="199.283,672.879 218.181,672.879 "/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="199.283,266.094 218.181,266.094 "/>
<path clip-path="url(#clip820)" d="M151.339 1472.25 Q147.728 1472.25 145.899 1475.81 Q144.093 1479.35 144.093 1486.48 Q144.093 1493.59 145.899 1497.15 Q147.728 1500.7 151.339 1500.7 Q154.973 1500.7 156.779 1497.15 Q158.607 1493.59 158.607 1486.48 Q158.607 1479.35 156.779 1475.81 Q154.973 1472.25 151.339 1472.25 M151.339 1468.54 Q157.149 1468.54 160.205 1473.15 Q163.283 1477.73 163.283 1486.48 Q163.283 1495.21 160.205 1499.82 Q157.149 1504.4 151.339 1504.4 Q145.529 1504.4 142.45 1499.82 Q139.394 1495.21 139.394 1486.48 Q139.394 1477.73 142.45 1473.15 Q145.529 1468.54 151.339 1468.54 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M81.0614 1062.38 L99.4178 1062.38 L99.4178 1066.32 L85.3438 1066.32 L85.3438 1074.79 Q86.3623 1074.44 87.3808 1074.28 Q88.3993 1074.1 89.4178 1074.1 Q95.2049 1074.1 98.5845 1077.27 Q101.964 1080.44 101.964 1085.86 Q101.964 1091.43 98.4919 1094.54 Q95.0197 1097.61 88.7003 1097.61 Q86.5243 1097.61 84.2558 1097.24 Q82.0105 1096.87 79.6031 1096.13 L79.6031 1091.43 Q81.6864 1092.57 83.9086 1093.12 Q86.1308 1093.68 88.6077 1093.68 Q92.6123 1093.68 94.9502 1091.57 Q97.2882 1089.47 97.2882 1085.86 Q97.2882 1082.24 94.9502 1080.14 Q92.6123 1078.03 88.6077 1078.03 Q86.7327 1078.03 84.8577 1078.45 Q83.0058 1078.86 81.0614 1079.74 L81.0614 1062.38 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M121.177 1065.46 Q117.566 1065.46 115.737 1069.03 Q113.932 1072.57 113.932 1079.7 Q113.932 1086.8 115.737 1090.37 Q117.566 1093.91 121.177 1093.91 Q124.811 1093.91 126.617 1090.37 Q128.445 1086.8 128.445 1079.7 Q128.445 1072.57 126.617 1069.03 Q124.811 1065.46 121.177 1065.46 M121.177 1061.76 Q126.987 1061.76 130.043 1066.36 Q133.121 1070.95 133.121 1079.7 Q133.121 1088.42 130.043 1093.03 Q126.987 1097.61 121.177 1097.61 Q115.367 1097.61 112.288 1093.03 Q109.233 1088.42 109.233 1079.7 Q109.233 1070.95 112.288 1066.36 Q115.367 1061.76 121.177 1061.76 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M151.339 1065.46 Q147.728 1065.46 145.899 1069.03 Q144.093 1072.57 144.093 1079.7 Q144.093 1086.8 145.899 1090.37 Q147.728 1093.91 151.339 1093.91 Q154.973 1093.91 156.779 1090.37 Q158.607 1086.8 158.607 1079.7 Q158.607 1072.57 156.779 1069.03 Q154.973 1065.46 151.339 1065.46 M151.339 1061.76 Q157.149 1061.76 160.205 1066.36 Q163.283 1070.95 163.283 1079.7 Q163.283 1088.42 160.205 1093.03 Q157.149 1097.61 151.339 1097.61 Q145.529 1097.61 142.45 1093.03 Q139.394 1088.42 139.394 1079.7 Q139.394 1070.95 142.45 1066.36 Q145.529 1061.76 151.339 1061.76 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M51.6634 686.224 L59.3023 686.224 L59.3023 659.858 L50.9921 661.525 L50.9921 657.265 L59.256 655.599 L63.9319 655.599 L63.9319 686.224 L71.5707 686.224 L71.5707 690.159 L51.6634 690.159 L51.6634 686.224 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M91.0151 658.677 Q87.404 658.677 85.5753 662.242 Q83.7697 665.784 83.7697 672.913 Q83.7697 680.02 85.5753 683.585 Q87.404 687.126 91.0151 687.126 Q94.6493 687.126 96.4548 683.585 Q98.2835 680.02 98.2835 672.913 Q98.2835 665.784 96.4548 662.242 Q94.6493 658.677 91.0151 658.677 M91.0151 654.974 Q96.8252 654.974 99.8808 659.58 Q102.959 664.164 102.959 672.913 Q102.959 681.64 99.8808 686.247 Q96.8252 690.83 91.0151 690.83 Q85.2049 690.83 82.1262 686.247 Q79.0707 681.64 79.0707 672.913 Q79.0707 664.164 82.1262 659.58 Q85.2049 654.974 91.0151 654.974 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M121.177 658.677 Q117.566 658.677 115.737 662.242 Q113.932 665.784 113.932 672.913 Q113.932 680.02 115.737 683.585 Q117.566 687.126 121.177 687.126 Q124.811 687.126 126.617 683.585 Q128.445 680.02 128.445 672.913 Q128.445 665.784 126.617 662.242 Q124.811 658.677 121.177 658.677 M121.177 654.974 Q126.987 654.974 130.043 659.58 Q133.121 664.164 133.121 672.913 Q133.121 681.64 130.043 686.247 Q126.987 690.83 121.177 690.83 Q115.367 690.83 112.288 686.247 Q109.233 681.64 109.233 672.913 Q109.233 664.164 112.288 659.58 Q115.367 654.974 121.177 654.974 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M151.339 658.677 Q147.728 658.677 145.899 662.242 Q144.093 665.784 144.093 672.913 Q144.093 680.02 145.899 683.585 Q147.728 687.126 151.339 687.126 Q154.973 687.126 156.779 683.585 Q158.607 680.02 158.607 672.913 Q158.607 665.784 156.779 662.242 Q154.973 658.677 151.339 658.677 M151.339 654.974 Q157.149 654.974 160.205 659.58 Q163.283 664.164 163.283 672.913 Q163.283 681.64 160.205 686.247 Q157.149 690.83 151.339 690.83 Q145.529 690.83 142.45 686.247 Q139.394 681.64 139.394 672.913 Q139.394 664.164 142.45 659.58 Q145.529 654.974 151.339 654.974 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M51.6634 279.439 L59.3023 279.439 L59.3023 253.073 L50.9921 254.74 L50.9921 250.481 L59.256 248.814 L63.9319 248.814 L63.9319 279.439 L71.5707 279.439 L71.5707 283.374 L51.6634 283.374 L51.6634 279.439 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M81.0614 248.814 L99.4178 248.814 L99.4178 252.749 L85.3438 252.749 L85.3438 261.222 Q86.3623 260.874 87.3808 260.712 Q88.3993 260.527 89.4178 260.527 Q95.2049 260.527 98.5845 263.698 Q101.964 266.87 101.964 272.286 Q101.964 277.865 98.4919 280.967 Q95.0197 284.045 88.7003 284.045 Q86.5243 284.045 84.2558 283.675 Q82.0105 283.305 79.6031 282.564 L79.6031 277.865 Q81.6864 278.999 83.9086 279.555 Q86.1308 280.11 88.6077 280.11 Q92.6123 280.11 94.9502 278.004 Q97.2882 275.897 97.2882 272.286 Q97.2882 268.675 94.9502 266.569 Q92.6123 264.462 88.6077 264.462 Q86.7327 264.462 84.8577 264.879 Q83.0058 265.296 81.0614 266.175 L81.0614 248.814 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M121.177 251.893 Q117.566 251.893 115.737 255.458 Q113.932 258.999 113.932 266.129 Q113.932 273.235 115.737 276.8 Q117.566 280.342 121.177 280.342 Q124.811 280.342 126.617 276.8 Q128.445 273.235 128.445 266.129 Q128.445 258.999 126.617 255.458 Q124.811 251.893 121.177 251.893 M121.177 248.189 Q126.987 248.189 130.043 252.796 Q133.121 257.379 133.121 266.129 Q133.121 274.856 130.043 279.462 Q126.987 284.045 121.177 284.045 Q115.367 284.045 112.288 279.462 Q109.233 274.856 109.233 266.129 Q109.233 257.379 112.288 252.796 Q115.367 248.189 121.177 248.189 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M151.339 251.893 Q147.728 251.893 145.899 255.458 Q144.093 258.999 144.093 266.129 Q144.093 273.235 145.899 276.8 Q147.728 280.342 151.339 280.342 Q154.973 280.342 156.779 276.8 Q158.607 273.235 158.607 266.129 Q158.607 258.999 156.779 255.458 Q154.973 251.893 151.339 251.893 M151.339 248.189 Q157.149 248.189 160.205 252.796 Q163.283 257.379 163.283 266.129 Q163.283 274.856 160.205 279.462 Q157.149 284.045 151.339 284.045 Q145.529 284.045 142.45 279.462 Q139.394 274.856 139.394 266.129 Q139.394 257.379 142.45 252.796 Q145.529 248.189 151.339 248.189 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip822)" d="M317.728 1419.74 L317.728 1486.45 L360.319 1486.45 L360.319 1419.74 L317.728 1419.74 L317.728 1419.74  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="317.728,1419.74 317.728,1486.45 360.319,1486.45 360.319,1419.74 317.728,1419.74 "/>
<path clip-path="url(#clip822)" d="M360.319 1486.45 L360.319 1486.45 L402.909 1486.45 L402.909 1486.45 L360.319 1486.45 L360.319 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="360.319,1486.45 360.319,1486.45 402.909,1486.45 360.319,1486.45 "/>
<path clip-path="url(#clip822)" d="M402.909 1486.45 L402.909 1486.45 L445.5 1486.45 L445.5 1486.45 L402.909 1486.45 L402.909 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="402.909,1486.45 402.909,1486.45 445.5,1486.45 402.909,1486.45 "/>
<path clip-path="url(#clip822)" d="M445.5 1486.45 L445.5 1486.45 L488.091 1486.45 L488.091 1486.45 L445.5 1486.45 L445.5 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="445.5,1486.45 445.5,1486.45 488.091,1486.45 445.5,1486.45 "/>
<path clip-path="url(#clip822)" d="M488.091 1341.63 L488.091 1486.45 L530.682 1486.45 L530.682 1341.63 L488.091 1341.63 L488.091 1341.63  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="488.091,1341.63 488.091,1486.45 530.682,1486.45 530.682,1341.63 488.091,1341.63 "/>
<path clip-path="url(#clip822)" d="M530.682 1486.45 L530.682 1486.45 L573.272 1486.45 L573.272 1486.45 L530.682 1486.45 L530.682 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="530.682,1486.45 530.682,1486.45 573.272,1486.45 530.682,1486.45 "/>
<path clip-path="url(#clip822)" d="M573.272 1486.45 L573.272 1486.45 L615.863 1486.45 L615.863 1486.45 L573.272 1486.45 L573.272 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="573.272,1486.45 573.272,1486.45 615.863,1486.45 573.272,1486.45 "/>
<path clip-path="url(#clip822)" d="M615.863 1486.45 L615.863 1486.45 L658.454 1486.45 L658.454 1486.45 L615.863 1486.45 L615.863 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="615.863,1486.45 615.863,1486.45 658.454,1486.45 615.863,1486.45 "/>
<path clip-path="url(#clip822)" d="M658.454 985.289 L658.454 1486.45 L701.045 1486.45 L701.045 985.289 L658.454 985.289 L658.454 985.289  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="658.454,985.289 658.454,1486.45 701.045,1486.45 701.045,985.289 658.454,985.289 "/>
<path clip-path="url(#clip822)" d="M701.045 1486.45 L701.045 1486.45 L743.635 1486.45 L743.635 1486.45 L701.045 1486.45 L701.045 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="701.045,1486.45 701.045,1486.45 743.635,1486.45 701.045,1486.45 "/>
<path clip-path="url(#clip822)" d="M743.635 1486.45 L743.635 1486.45 L786.226 1486.45 L786.226 1486.45 L743.635 1486.45 L743.635 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="743.635,1486.45 743.635,1486.45 786.226,1486.45 743.635,1486.45 "/>
<path clip-path="url(#clip822)" d="M786.226 659.862 L786.226 1486.45 L828.817 1486.45 L828.817 659.862 L786.226 659.862 L786.226 659.862  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="786.226,659.862 786.226,1486.45 828.817,1486.45 828.817,659.862 786.226,659.862 "/>
<path clip-path="url(#clip822)" d="M828.817 1486.45 L828.817 1486.45 L871.408 1486.45 L871.408 1486.45 L828.817 1486.45 L828.817 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="828.817,1486.45 828.817,1486.45 871.408,1486.45 828.817,1486.45 "/>
<path clip-path="url(#clip822)" d="M871.408 1486.45 L871.408 1486.45 L913.998 1486.45 L913.998 1486.45 L871.408 1486.45 L871.408 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="871.408,1486.45 871.408,1486.45 913.998,1486.45 871.408,1486.45 "/>
<path clip-path="url(#clip822)" d="M913.998 1486.45 L913.998 1486.45 L956.589 1486.45 L956.589 1486.45 L913.998 1486.45 L913.998 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="913.998,1486.45 913.998,1486.45 956.589,1486.45 913.998,1486.45 "/>
<path clip-path="url(#clip822)" d="M956.589 406.842 L956.589 1486.45 L999.18 1486.45 L999.18 406.842 L956.589 406.842 L956.589 406.842  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="956.589,406.842 956.589,1486.45 999.18,1486.45 999.18,406.842 956.589,406.842 "/>
<path clip-path="url(#clip822)" d="M999.18 1486.45 L999.18 1486.45 L1041.77 1486.45 L1041.77 1486.45 L999.18 1486.45 L999.18 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="999.18,1486.45 999.18,1486.45 1041.77,1486.45 999.18,1486.45 "/>
<path clip-path="url(#clip822)" d="M1041.77 1486.45 L1041.77 1486.45 L1084.36 1486.45 L1084.36 1486.45 L1041.77 1486.45 L1041.77 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1041.77,1486.45 1041.77,1486.45 1084.36,1486.45 1041.77,1486.45 "/>
<path clip-path="url(#clip822)" d="M1084.36 1486.45 L1084.36 1486.45 L1126.95 1486.45 L1126.95 1486.45 L1084.36 1486.45 L1084.36 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1084.36,1486.45 1084.36,1486.45 1126.95,1486.45 1084.36,1486.45 "/>
<path clip-path="url(#clip822)" d="M1126.95 51.3119 L1126.95 1486.45 L1169.54 1486.45 L1169.54 51.3119 L1126.95 51.3119 L1126.95 51.3119  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1126.95,51.3119 1126.95,1486.45 1169.54,1486.45 1169.54,51.3119 1126.95,51.3119 "/>
<path clip-path="url(#clip822)" d="M1169.54 1486.45 L1169.54 1486.45 L1212.13 1486.45 L1212.13 1486.45 L1169.54 1486.45 L1169.54 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1169.54,1486.45 1169.54,1486.45 1212.13,1486.45 1169.54,1486.45 "/>
<path clip-path="url(#clip822)" d="M1212.13 1486.45 L1212.13 1486.45 L1254.72 1486.45 L1254.72 1486.45 L1212.13 1486.45 L1212.13 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1212.13,1486.45 1212.13,1486.45 1254.72,1486.45 1212.13,1486.45 "/>
<path clip-path="url(#clip822)" d="M1254.72 1486.45 L1254.72 1486.45 L1297.31 1486.45 L1297.31 1486.45 L1254.72 1486.45 L1254.72 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1254.72,1486.45 1254.72,1486.45 1297.31,1486.45 1254.72,1486.45 "/>
<path clip-path="url(#clip822)" d="M1297.31 47.2441 L1297.31 1486.45 L1339.91 1486.45 L1339.91 47.2441 L1297.31 47.2441 L1297.31 47.2441  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1297.31,47.2441 1297.31,1486.45 1339.91,1486.45 1339.91,47.2441 1297.31,47.2441 "/>
<path clip-path="url(#clip822)" d="M1339.91 1486.45 L1339.91 1486.45 L1382.5 1486.45 L1382.5 1486.45 L1339.91 1486.45 L1339.91 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1339.91,1486.45 1339.91,1486.45 1382.5,1486.45 1339.91,1486.45 "/>
<path clip-path="url(#clip822)" d="M1382.5 1486.45 L1382.5 1486.45 L1425.09 1486.45 L1425.09 1486.45 L1382.5 1486.45 L1382.5 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1382.5,1486.45 1382.5,1486.45 1425.09,1486.45 1382.5,1486.45 "/>
<path clip-path="url(#clip822)" d="M1425.09 1486.45 L1425.09 1486.45 L1467.68 1486.45 L1467.68 1486.45 L1425.09 1486.45 L1425.09 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1425.09,1486.45 1425.09,1486.45 1467.68,1486.45 1425.09,1486.45 "/>
<path clip-path="url(#clip822)" d="M1467.68 1486.45 L1467.68 1486.45 L1510.27 1486.45 L1510.27 1486.45 L1467.68 1486.45 L1467.68 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1467.68,1486.45 1467.68,1486.45 1510.27,1486.45 1467.68,1486.45 "/>
<path clip-path="url(#clip822)" d="M1510.27 354.773 L1510.27 1486.45 L1552.86 1486.45 L1552.86 354.773 L1510.27 354.773 L1510.27 354.773  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1510.27,354.773 1510.27,1486.45 1552.86,1486.45 1552.86,354.773 1510.27,354.773 "/>
<path clip-path="url(#clip822)" d="M1552.86 1486.45 L1552.86 1486.45 L1595.45 1486.45 L1595.45 1486.45 L1552.86 1486.45 L1552.86 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1552.86,1486.45 1552.86,1486.45 1595.45,1486.45 1552.86,1486.45 "/>
<path clip-path="url(#clip822)" d="M1595.45 1486.45 L1595.45 1486.45 L1638.04 1486.45 L1638.04 1486.45 L1595.45 1486.45 L1595.45 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1595.45,1486.45 1595.45,1486.45 1638.04,1486.45 1595.45,1486.45 "/>
<path clip-path="url(#clip822)" d="M1638.04 1486.45 L1638.04 1486.45 L1680.63 1486.45 L1680.63 1486.45 L1638.04 1486.45 L1638.04 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1638.04,1486.45 1638.04,1486.45 1680.63,1486.45 1638.04,1486.45 "/>
<path clip-path="url(#clip822)" d="M1680.63 661.489 L1680.63 1486.45 L1723.22 1486.45 L1723.22 661.489 L1680.63 661.489 L1680.63 661.489  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1680.63,661.489 1680.63,1486.45 1723.22,1486.45 1723.22,661.489 1680.63,661.489 "/>
<path clip-path="url(#clip822)" d="M1723.22 1486.45 L1723.22 1486.45 L1765.81 1486.45 L1765.81 1486.45 L1723.22 1486.45 L1723.22 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1723.22,1486.45 1723.22,1486.45 1765.81,1486.45 1723.22,1486.45 "/>
<path clip-path="url(#clip822)" d="M1765.81 1486.45 L1765.81 1486.45 L1808.4 1486.45 L1808.4 1486.45 L1765.81 1486.45 L1765.81 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1765.81,1486.45 1765.81,1486.45 1808.4,1486.45 1765.81,1486.45 "/>
<path clip-path="url(#clip822)" d="M1808.4 1486.45 L1808.4 1486.45 L1850.99 1486.45 L1850.99 1486.45 L1808.4 1486.45 L1808.4 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1808.4,1486.45 1808.4,1486.45 1850.99,1486.45 1808.4,1486.45 "/>
<path clip-path="url(#clip822)" d="M1850.99 1025.15 L1850.99 1486.45 L1893.59 1486.45 L1893.59 1025.15 L1850.99 1025.15 L1850.99 1025.15  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1850.99,1025.15 1850.99,1486.45 1893.59,1486.45 1893.59,1025.15 1850.99,1025.15 "/>
<path clip-path="url(#clip822)" d="M1893.59 1486.45 L1893.59 1486.45 L1936.18 1486.45 L1936.18 1486.45 L1893.59 1486.45 L1893.59 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1893.59,1486.45 1893.59,1486.45 1936.18,1486.45 1893.59,1486.45 "/>
<path clip-path="url(#clip822)" d="M1936.18 1486.45 L1936.18 1486.45 L1978.77 1486.45 L1978.77 1486.45 L1936.18 1486.45 L1936.18 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1936.18,1486.45 1936.18,1486.45 1978.77,1486.45 1936.18,1486.45 "/>
<path clip-path="url(#clip822)" d="M1978.77 1486.45 L1978.77 1486.45 L2021.36 1486.45 L2021.36 1486.45 L1978.77 1486.45 L1978.77 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="1978.77,1486.45 1978.77,1486.45 2021.36,1486.45 1978.77,1486.45 "/>
<path clip-path="url(#clip822)" d="M2021.36 1318.85 L2021.36 1486.45 L2063.95 1486.45 L2063.95 1318.85 L2021.36 1318.85 L2021.36 1318.85  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2021.36,1318.85 2021.36,1486.45 2063.95,1486.45 2063.95,1318.85 2021.36,1318.85 "/>
<path clip-path="url(#clip822)" d="M2063.95 1486.45 L2063.95 1486.45 L2106.54 1486.45 L2106.54 1486.45 L2063.95 1486.45 L2063.95 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2063.95,1486.45 2063.95,1486.45 2106.54,1486.45 2063.95,1486.45 "/>
<path clip-path="url(#clip822)" d="M2106.54 1486.45 L2106.54 1486.45 L2149.13 1486.45 L2149.13 1486.45 L2106.54 1486.45 L2106.54 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2106.54,1486.45 2106.54,1486.45 2149.13,1486.45 2106.54,1486.45 "/>
<path clip-path="url(#clip822)" d="M2149.13 1486.45 L2149.13 1486.45 L2191.72 1486.45 L2191.72 1486.45 L2149.13 1486.45 L2149.13 1486.45  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2149.13,1486.45 2149.13,1486.45 2191.72,1486.45 2149.13,1486.45 "/>
<path clip-path="url(#clip822)" d="M2191.72 1429.5 L2191.72 1486.45 L2234.31 1486.45 L2234.31 1429.5 L2191.72 1429.5 L2191.72 1429.5  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip822)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2191.72,1429.5 2191.72,1486.45 2234.31,1486.45 2234.31,1429.5 2191.72,1429.5 "/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="339.023" cy="1419.74" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="381.614" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="424.205" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="466.796" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="509.386" cy="1341.63" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="551.977" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="594.568" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="637.159" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="679.749" cy="985.289" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="722.34" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="764.931" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="807.521" cy="659.862" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="850.112" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="892.703" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="935.294" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="977.884" cy="406.842" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1020.48" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1063.07" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1105.66" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1148.25" cy="51.3119" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1190.84" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1233.43" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1276.02" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1318.61" cy="47.2441" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1361.2" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1403.79" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1446.38" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1488.97" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1531.56" cy="354.773" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1574.15" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1616.75" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1659.34" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1701.93" cy="661.489" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1744.52" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1787.11" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1829.7" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1872.29" cy="1025.15" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1914.88" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="1957.47" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="2000.06" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="2042.65" cy="1318.85" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="2085.24" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="2127.83" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="2170.42" cy="1486.45" r="2"/>
<circle clip-path="url(#clip822)" style="fill:#009af9; stroke:none; fill-opacity:0" cx="2213.02" cy="1429.5" r="2"/>
<path clip-path="url(#clip820)" d="M2013.2 198.898 L2280.97 198.898 L2280.97 95.2176 L2013.2 95.2176  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2013.2,198.898 2280.97,198.898 2280.97,95.2176 2013.2,95.2176 2013.2,198.898 "/>
<path clip-path="url(#clip820)" d="M2037.12 167.794 L2180.69 167.794 L2180.69 126.322 L2037.12 126.322 L2037.12 167.794  Z" fill="#009af9" fill-rule="evenodd" fill-opacity="1"/>
<polyline clip-path="url(#clip820)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:1; fill:none" points="2037.12,167.794 2180.69,167.794 2180.69,126.322 2037.12,126.322 2037.12,167.794 "/>
<path clip-path="url(#clip820)" d="M2218.46 166.745 Q2216.65 171.375 2214.94 172.787 Q2213.23 174.199 2210.36 174.199 L2206.95 174.199 L2206.95 170.634 L2209.45 170.634 Q2211.21 170.634 2212.19 169.8 Q2213.16 168.967 2214.34 165.865 L2215.1 163.921 L2204.62 138.412 L2209.13 138.412 L2217.23 158.689 L2225.33 138.412 L2229.85 138.412 L2218.46 166.745 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /><path clip-path="url(#clip820)" d="M2237.14 160.402 L2244.78 160.402 L2244.78 134.037 L2236.47 135.703 L2236.47 131.444 L2244.73 129.778 L2249.41 129.778 L2249.41 160.402 L2257.05 160.402 L2257.05 164.338 L2237.14 164.338 L2237.14 160.402 Z" fill="#000000" fill-rule="nonzero" fill-opacity="1" /></svg>





```julia
freqtable(result.samples)
```




    12-element Named Vector{Int64}
    Dim1  │ 
    ──────┼─────
    -2.2  │   82
    -1.8  │  178
    -1.4  │  616
    -1.0  │ 1016
    -0.6  │ 1327
    -0.2  │ 1764
    0.2   │ 1769
    0.6   │ 1391
    1.0   │ 1014
    1.4   │  567
    1.8   │  206
    2.2   │   70




```julia
mean(abs.(result.samples) .>=  abs(result.observation)) # -1 以下，または 1 以上の割合が $p$ 値
```




    0.3749


